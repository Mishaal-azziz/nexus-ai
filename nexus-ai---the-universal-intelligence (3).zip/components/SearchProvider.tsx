import React, { useState, useRef, useEffect } from 'react';
import { GroundingChunk, FileData, Conversation } from '../types';

interface SearchProviderProps {
  conversation: Conversation | null;
  onSubmit: (prompt: string, attachment?: FileData) => void;
  isLoading: boolean;
}

const SearchProvider: React.FC<SearchProviderProps> = ({ conversation, onSubmit, isLoading }) => {
  const [query, setQuery] = useState('');
  const [attachment, setAttachment] = useState<FileData | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [copiedTurnId, setCopiedTurnId] = useState<string | null>(null);
  const [isSpeakingId, setIsSpeakingId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [conversation?.turns.length, isLoading]);

  const performSearch = (overrideQuery?: string) => {
    const finalQuery = overrideQuery !== undefined ? overrideQuery : query;
    if (!finalQuery.trim() && !attachment) return;
    onSubmit(finalQuery, attachment || undefined);
    setQuery('');
    setAttachment(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachment({
          data: reader.result as string,
          mimeType: file.type,
          name: file.name,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const startVoiceSearch = () => {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      alert('Voice input is not supported in this browser.');
      return;
    }
    const recognition = new SpeechRec();
    recognition.lang = 'en-US';
    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onerror = () => setIsRecording(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results?.[0]?.[0]?.transcript;
      if (transcript) {
        setQuery(transcript);
        performSearch(transcript);
      }
    };
    recognition.start();
  };

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(url);
    setTimeout(() => setCopiedLink(null), 2000);
  };

  const copyResponseText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTurnId(id);
    setTimeout(() => setCopiedTurnId(null), 2000);
  };

  const speakText = (text: string, id: string) => {
    if (!('speechSynthesis' in window)) return;
    if (isSpeakingId === id) {
      window.speechSynthesis.cancel();
      setIsSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 1000));
    utterance.onend = () => setIsSpeakingId(null);
    utterance.onerror = () => setIsSpeakingId(null);
    setIsSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const sampleSearches = [
    'Latest scientific breakthroughs in fusion energy in 2026',
    'NASA Artemis lunar missions current status and timeline',
    'Best architectural patterns for real-time AI applications',
    'Recent discoveries by the James Webb Space Telescope',
  ];

  const turns = conversation?.turns || [];

  return (
    <div className="h-full flex flex-col p-3 sm:p-6 max-w-5xl mx-auto space-y-4 sm:space-y-6 overflow-hidden relative">
      {/* Header */}
      <div className="max-w-3xl mx-auto w-full text-center space-y-1.5 flex-shrink-0">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>ADVANCED CHAT • LIVE GOOGLE SEARCH GROUNDING</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-black bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent tracking-tight">
          Advanced Chat
        </h2>
        <p className="text-gray-400 text-xs sm:text-sm max-w-lg mx-auto">
          Multi-turn conversational intelligence verified with live web research, source citations, and direct reference links.
        </p>
      </div>

      {/* Messages Scroll Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-6 pb-28 pr-1 sm:pr-2 scrollbar-thin min-h-0 select-text">
        {turns.length === 0 ? (
          <div className="max-w-2xl mx-auto py-8 space-y-6 animate-in fade-in duration-500">
            <div className="text-center opacity-70 space-y-2">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
              </div>
              <h3 className="text-lg font-bold text-white">Ask anything with real-time web verification</h3>
              <p className="text-xs text-gray-400">
                Nexus fact-checks in real-time, extracts sources, and delivers direct verified links.
              </p>
            </div>

            <div className="space-y-2">
              <div className="text-[10px] font-mono uppercase tracking-widest text-gray-500 text-center">
                Popular Inquiries
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {sampleSearches.map((sample, i) => (
                  <button
                    key={i}
                    onClick={() => performSearch(sample)}
                    className="p-3.5 rounded-2xl bg-white/5 hover:bg-emerald-500/10 border border-white/5 hover:border-emerald-500/30 text-left text-xs font-medium text-gray-300 hover:text-emerald-300 transition-all flex items-center justify-between group"
                  >
                    <span className="truncate">{sample}</span>
                    <svg className="w-4 h-4 text-gray-500 group-hover:text-emerald-300 group-hover:translate-x-1 transition-all flex-shrink-0 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          turns.map((turn) => {
            const chunks: GroundingChunk[] = turn.response.metadata?.chunks || [];

            return (
              <div key={turn.id} className="space-y-4 animate-in fade-in duration-300">
                {/* User Message Bubble */}
                <div className="flex justify-end">
                  <div className="max-w-[85%] sm:max-w-[75%] p-4 sm:p-5 rounded-[2rem] rounded-tr-lg bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xl shadow-emerald-500/10 text-sm sm:text-base leading-relaxed">
                    <p className="whitespace-pre-wrap">{turn.prompt}</p>
                  </div>
                </div>

                {/* Assistant Grounded Response Card */}
                <div className="flex justify-start">
                  <div className="max-w-[95%] sm:max-w-[85%] p-5 sm:p-7 rounded-[2rem] rounded-tl-lg bg-[#11192e]/90 border border-white/10 text-gray-100 shadow-2xl backdrop-blur-xl space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-white/5 text-xs">
                      <div className="flex items-center space-x-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300 orbitron">
                          Advanced Grounded Result
                        </span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <button
                          onClick={() => copyResponseText(turn.response.content, turn.response.id)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-white transition-colors"
                          title="Copy response"
                        >
                          {copiedTurnId === turn.response.id ? (
                            <span className="text-[10px] text-emerald-400 font-bold">✓</span>
                          ) : (
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                            </svg>
                          )}
                        </button>
                        <button
                          onClick={() => speakText(turn.response.content, turn.response.id)}
                          className={`p-1.5 rounded-lg transition-colors ${
                            isSpeakingId === turn.response.id ? 'text-emerald-400 bg-emerald-500/20' : 'text-gray-400 hover:text-white'
                          }`}
                          title="Read aloud"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                          </svg>
                        </button>
                      </div>
                    </div>

                    {/* Grounded text */}
                    <div className="text-sm sm:text-base leading-relaxed text-gray-100 whitespace-pre-wrap font-normal">
                      {turn.response.content}
                    </div>

                    {/* Source Links Grid */}
                    {chunks.length > 0 && (
                      <div className="pt-3 border-t border-white/5 space-y-2">
                        <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                          <svg className="w-3.5 h-3.5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                          </svg>
                          <span>Verified Web Sources ({chunks.length})</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {chunks.map((chunk, idx) =>
                            chunk.web?.uri ? (
                              <div
                                key={idx}
                                className="p-3 bg-[#090f1d] hover:bg-emerald-950/20 border border-white/5 hover:border-emerald-500/30 rounded-2xl transition-all flex items-center justify-between group"
                              >
                                <a
                                  href={chunk.web.uri}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="min-w-0 flex-1 pr-2"
                                >
                                  <div className="text-[10px] text-emerald-400 font-mono truncate">
                                    {new URL(chunk.web.uri).hostname}
                                  </div>
                                  <div className="text-xs font-semibold text-gray-200 group-hover:text-emerald-300 truncate">
                                    {chunk.web.title || chunk.web.uri}
                                  </div>
                                </a>

                                <button
                                  onClick={() => copyUrl(chunk.web!.uri)}
                                  className="p-1.5 text-gray-400 hover:text-white rounded-lg bg-white/5 flex-shrink-0"
                                  title="Copy URL"
                                >
                                  {copiedLink === chunk.web.uri ? (
                                    <span className="text-[10px] text-emerald-400 font-bold">✓</span>
                                  ) : (
                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                    </svg>
                                  )}
                                </button>
                              </div>
                            ) : null
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-[#11192e] border border-white/10 p-4 rounded-3xl flex items-center space-x-3 shadow-xl">
              <div className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-bounce" />
              <div className="w-2.5 h-2.5 bg-teal-400 rounded-full animate-bounce [animation-delay:-.2s]" />
              <div className="w-2.5 h-2.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:-.4s]" />
              <span className="text-xs font-mono text-emerald-300 ml-2">Grounding with live web sources...</span>
            </div>
          </div>
        )}
      </div>

      {/* Floating Bottom Input Bar */}
      <div className="absolute bottom-3 sm:bottom-5 left-3 right-3 sm:left-6 sm:right-6 max-w-4xl mx-auto">
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-500 rounded-full blur-xl opacity-20 group-focus-within:opacity-50 transition duration-500" />
          <div className="relative flex items-center bg-[#0d1527]/95 backdrop-blur-2xl border border-white/15 rounded-full shadow-2xl p-1.5 sm:p-2 pl-3 sm:pl-4 pr-2 sm:pr-3">
            <input
              type="file"
              className="hidden"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/*,application/pdf,text/*"
            />
            
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className={`p-2.5 rounded-full transition-colors flex-shrink-0 ${
                attachment ? 'bg-emerald-600 text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
              title="Attach document or image"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
              </svg>
            </button>

            <button
              type="button"
              onClick={startVoiceSearch}
              className={`p-2.5 rounded-full transition-colors flex-shrink-0 ${
                isRecording ? 'text-red-400 bg-red-500/20 animate-pulse' : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
              title="Voice Input"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            </button>

            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  performSearch();
                }
              }}
              placeholder={isRecording ? 'Listening...' : 'Ask Advanced Chat with live web grounding...'}
              className="flex-1 bg-transparent border-none py-3 px-3 sm:px-4 text-white placeholder-gray-500 focus:ring-0 outline-none text-sm sm:text-base min-w-0"
              disabled={isLoading}
            />

            <button
              onClick={() => performSearch()}
              disabled={isLoading || (!query.trim() && !attachment)}
              className="p-3 sm:p-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 text-white rounded-full transition-all shadow-lg hover:scale-105 active:scale-95 flex-shrink-0"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchProvider;
