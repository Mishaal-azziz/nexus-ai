import React from 'react';
import { AppMode, StemSubMode, Conversation } from '../types';

interface SidebarProps {
  activeMode: AppMode;
  setMode: (mode: AppMode) => void;
  activeStemSubMode: StemSubMode;
  setStemSubMode: (subMode: StemSubMode) => void;
  conversations: Conversation[];
  activeConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  isMobileOpen?: boolean;
  onMobileClose?: () => void;
  onReturnToWelcome?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  activeMode,
  setMode,
  activeStemSubMode,
  setStemSubMode,
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewConversation,
  isMobileOpen = false,
  onMobileClose,
  onReturnToWelcome,
}) => {
  const navItems = [
    {
      mode: AppMode.DASHBOARD,
      label: 'Overview',
      badge: 'Home',
      iconBg: 'bg-slate-100 text-slate-700',
      icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
        </svg>
      ),
    },
    {
      mode: AppMode.CHAT,
      label: 'Chatbot',
      badge: 'Chat',
      iconBg: 'bg-indigo-50 text-indigo-600',
      icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
        </svg>
      ),
    },
    {
      mode: AppMode.SEARCH,
      label: 'Advanced Search',
      badge: 'Web',
      iconBg: 'bg-emerald-50 text-emerald-600',
      icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
        </svg>
      ),
    },
    {
      mode: AppMode.CODE,
      label: 'Code Builder',
      badge: 'Code',
      iconBg: 'bg-slate-100 text-slate-800',
      icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
        </svg>
      ),
    },
    {
      mode: AppMode.PLANNER,
      label: 'AI Planner',
      badge: 'Plan',
      iconBg: 'bg-indigo-50 text-indigo-600',
      icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
        </svg>
      ),
    },
    {
      mode: AppMode.STEM,
      label: 'STEM Solver',
      badge: 'Math',
      iconBg: 'bg-amber-50 text-amber-600',
      icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
        </svg>
      ),
    },
    {
      mode: AppMode.TRANSLATE,
      label: 'Translator',
      badge: 'Translate',
      iconBg: 'bg-teal-50 text-teal-600',
      icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5c1.382 3.307 3.454 6.333 5.67 9" />
        </svg>
      ),
    },
    {
      mode: AppMode.AI_TUTOR,
      label: 'AI Tutor',
      badge: 'Tutor',
      iconBg: 'bg-emerald-50 text-emerald-600',
      icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5z M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z M12 14v6m-6-3h12" />
        </svg>
      ),
    },
  ];

  const stemSubNavItems = [
    { mode: StemSubMode.GENERAL, label: 'General' },
    { mode: StemSubMode.MATH, label: 'Mathematics' },
    { mode: StemSubMode.PHYSICS, label: 'Physics' },
    { mode: StemSubMode.CHEMISTRY, label: 'Chemistry' },
    { mode: StemSubMode.BIOLOGY, label: 'Biology' },
    { mode: StemSubMode.CS, label: 'Computer Science' },
    { mode: StemSubMode.ENGINEERING, label: 'Engineering' },
  ];

  const handleNavClick = (mode: AppMode) => {
    setMode(mode);
    if (onMobileClose) onMobileClose();
  };

  const modeConversations = conversations
    .filter((c) => c.mode === activeMode)
    .sort((a, b) => b.createdAt - a.createdAt);

  const sidebarContent = (
    <div className="flex flex-col h-full select-none text-slate-700">
      {/* Brand Header */}
      <div className="mb-4 px-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-sky-500 text-white flex items-center justify-center font-bold text-sm shadow-sm shadow-sky-500/20 flex-shrink-0">
            NX
          </div>
          <div>
            <div className="text-base font-bold text-slate-900 tracking-tight">Nexus AI</div>
            <div className="text-xs text-slate-500 font-normal">Intelligent Workspace</div>
          </div>
        </div>

        {onMobileClose && (
          <button
            onClick={onMobileClose}
            className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            aria-label="Close Navigation"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      {/* The Single Home Screen Button on the Sidebar */}
      {onReturnToWelcome && (
        <div className="px-2 mb-3">
          <button
            type="button"
            onClick={() => {
              onReturnToWelcome();
              if (onMobileClose) onMobileClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 font-semibold text-xs transition-all shadow-sm active:scale-[0.98] cursor-pointer hover:shadow"
            title="Return to Home Screen"
          >
            <svg className="w-4 h-4 text-sky-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            <span>Home Screen</span>
          </button>
        </div>
      )}

      {/* New Session Action */}
      {activeMode !== AppMode.DASHBOARD && (
        <div className="px-2 mb-4">
          <button
            onClick={() => {
              onNewConversation();
              if (onMobileClose) onMobileClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-medium text-xs shadow-sm shadow-sky-500/20 transition-all active:scale-[0.98] cursor-pointer"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            <span>New Conversation</span>
          </button>
        </div>
      )}

      {/* Nav List */}
      <div className="flex-1 overflow-y-auto px-1 space-y-1 scrollbar-thin">
        <div className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
          Tools
        </div>

        {navItems.map((item) => {
          const isActive = activeMode === item.mode;
          return (
            <React.Fragment key={item.mode}>
              <button
                onClick={() => handleNavClick(item.mode)}
                className={`flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors w-full text-left group cursor-pointer ${
                  isActive
                    ? 'bg-slate-100 text-slate-900 font-semibold'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 font-normal'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-lg ${item.iconBg} flex items-center justify-center flex-shrink-0 transition-transform ${
                      isActive ? 'scale-105' : 'group-hover:scale-105'
                    }`}
                  >
                    {item.icon}
                  </div>
                  <span className="text-xs sm:text-sm truncate">
                    {item.label}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-medium group-hover:text-slate-500">
                  {item.badge}
                </span>
              </button>

              {/* STEM Sub-navigation */}
              {item.mode === AppMode.STEM && isActive && (
                <div className="pl-4 py-1.5 space-y-1 border-l-2 border-slate-200 ml-4 mr-1">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 px-2 mb-1">
                    Subject
                  </div>
                  <div className="space-y-0.5">
                    {stemSubNavItems.map((sub) => (
                      <button
                        key={sub.mode}
                        onClick={() => {
                          setStemSubMode(sub.mode);
                          if (onMobileClose) onMobileClose();
                        }}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                          activeStemSubMode === sub.mode
                            ? 'bg-indigo-50 text-indigo-700 font-semibold'
                            : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                        }`}
                      >
                        {sub.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Conversation History for Current Mode */}
              {isActive && modeConversations.length > 0 && item.mode !== AppMode.DASHBOARD && (
                <div className="pl-4 py-1.5 space-y-1 border-l-2 border-slate-200 ml-4 mr-1">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 px-2 mb-1">
                    Recent
                  </div>
                  {modeConversations.slice(0, 5).map((convo) => (
                    <button
                      key={convo.id}
                      onClick={() => {
                        onSelectConversation(convo.id);
                        if (onMobileClose) onMobileClose();
                      }}
                      className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs truncate transition-colors cursor-pointer ${
                        activeConversationId === convo.id
                          ? 'bg-slate-100 text-slate-900 font-semibold'
                          : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                      }`}
                    >
                      {convo.title}
                    </button>
                  ))}
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Footer Status */}
      <div className="mt-4 pt-3 border-t border-slate-200/80 px-2">
        <div className="flex items-center justify-between text-xs text-slate-500 px-1">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="font-medium text-slate-600">Gemini 3.8</span>
          </span>
          <span className="text-[11px] text-slate-400 font-medium">Ready</span>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="w-64 lg:w-72 bg-white rounded-3xl border border-slate-200/80 flex flex-col p-4 hidden md:flex shadow-sm flex-shrink-0">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm transition-opacity"
            onClick={onMobileClose}
          />
          <div className="relative w-[85vw] max-w-sm bg-white border-r border-slate-200 p-4 h-full z-10 shadow-xl flex flex-col">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};

export default Sidebar;
