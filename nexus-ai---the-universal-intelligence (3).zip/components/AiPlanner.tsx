import React, { useState, useEffect, useRef } from 'react';
import { Conversation, FileData, PlannerCategory, PlannerTimeframe, PlannerPacing, PlanTaskItem } from '../types';
import { geminiService } from '../geminiService';

interface AiPlannerProps {
  conversation: Conversation | null;
  onSubmit: (prompt: string, attachment?: FileData) => void;
  isLoading: boolean;
}

const CATEGORY_CONFIGS = [
  { id: PlannerCategory.DAILY_SCHEDULE, icon: '🗓️', label: 'Daily Schedule', hint: '24-hour block, morning routine, deep work hours' },
  { id: PlannerCategory.PROJECT_ROADMAP, icon: '🚀', label: 'Project Roadmap', hint: 'Phased deliverables, milestones, tech sprints' },
  { id: PlannerCategory.STUDY_EXAM, icon: '📚', label: 'Study & Exam', hint: 'Spaced repetition, mock tests, subject focus' },
  { id: PlannerCategory.TRAVEL_ITINERARY, icon: '✈️', label: 'Travel Itinerary', hint: 'Day-by-day sights, transit, budget, dining' },
  { id: PlannerCategory.FITNESS_MEAL, icon: '🥗', label: 'Fitness & Nutrition', hint: 'Split workout schedule, meal prep, hydration' },
  { id: PlannerCategory.EVENT_PARTY, icon: '🎉', label: 'Event & Launch', hint: 'Timeline countdown, vendor checklist, logistics' },
  { id: PlannerCategory.BUDGET_FINANCE, icon: '💰', label: 'Budget & Goals', hint: 'Savings targets, expense limits, weekly milestones' },
  { id: PlannerCategory.CUSTOM, icon: '⚡', label: 'Custom Plan', hint: 'Any custom workflow, habit tracker, or strategy' },
];

const TIMEFRAME_OPTIONS = [
  { id: PlannerTimeframe.TODAY, label: '24 Hours / Today' },
  { id: PlannerTimeframe.WEEK_SPRINT, label: '7-Day Sprint' },
  { id: PlannerTimeframe.MONTH, label: '30-Day Plan' },
  { id: PlannerTimeframe.QUARTER, label: 'Quarterly (3 Mo)' },
  { id: PlannerTimeframe.LONG_TERM, label: 'Long-Term Roadmap' },
];

const PACING_OPTIONS = [
  { id: PlannerPacing.BALANCED, label: 'Balanced & Sustainable', icon: '⚖️' },
  { id: PlannerPacing.INTENSIVE, label: 'High Intensity / Fast', icon: '⚡' },
  { id: PlannerPacing.RELAXED, label: 'Gentle & Low Stress', icon: '🌿' },
];

const QUICK_STARTERS = [
  {
    category: PlannerCategory.DAILY_SCHEDULE,
    timeframe: PlannerTimeframe.TODAY,
    title: 'Peak Productivity Day',
    prompt: 'Create a focused 24-hour daily schedule starting at 7:00 AM with deep work blocks, lunch, exercise, and evening wind-down.',
  },
  {
    category: PlannerCategory.PROJECT_ROADMAP,
    timeframe: PlannerTimeframe.WEEK_SPRINT,
    title: 'MVP Launch Sprint',
    prompt: 'Build a 7-day development sprint plan to design, build, test, and deploy a full-stack SaaS MVP.',
  },
  {
    category: PlannerCategory.STUDY_EXAM,
    timeframe: PlannerTimeframe.MONTH,
    title: 'Exam Study Sprint',
    prompt: 'Organize a 4-week study plan with active recall, spaced repetition, mock exams, and rest intervals.',
  },
  {
    category: PlannerCategory.TRAVEL_ITINERARY,
    timeframe: PlannerTimeframe.WEEK_SPRINT,
    title: 'Tokyo 5-Day Trip',
    prompt: 'Plan a 5-day cultural and culinary itinerary in Tokyo, Japan with district-by-district sights and transit tips.',
  },
  {
    category: PlannerCategory.FITNESS_MEAL,
    timeframe: PlannerTimeframe.WEEK_SPRINT,
    title: 'Weekly Workout & Meal Prep',
    prompt: 'Create a balanced 7-day push/pull/legs workout schedule with simple high-protein meal prep guidelines.',
  },
  {
    category: PlannerCategory.BUDGET_FINANCE,
    timeframe: PlannerTimeframe.MONTH,
    title: '30-Day Budget Reset',
    prompt: 'Develop a 30-day personal finance savings roadmap using the 50/30/20 rule with weekly spending checkpoints.',
  },
];

const REFINE_CHIPS = [
  'Add 15% buffer time between tasks',
  'Break into smaller 30-minute steps',
  'Make this more budget-friendly',
  'Add morning and evening rituals',
  'Include a checklist for day 1',
  'Prioritize tasks with Eisenhower Matrix',
];

export const AiPlanner: React.FC<AiPlannerProps> = ({ conversation, onSubmit, isLoading }) => {
  const [input, setInput] = useState('');
  const [category, setCategory] = useState<PlannerCategory>(PlannerCategory.DAILY_SCHEDULE);
  const [timeframe, setTimeframe] = useState<PlannerTimeframe>(PlannerTimeframe.WEEK_SPRINT);
  const [pacing, setPacing] = useState<PlannerPacing>(PlannerPacing.BALANCED);
  const [showOptions, setShowOptions] = useState(false);
  const [copied, setCopied] = useState(false);
  const [completedTasks, setCompletedTasks] = useState<Record<string, boolean>>({});

  const chatEndRef = useRef<HTMLDivElement>(null);
  const turns = conversation?.turns || [];
  const latestTurn = turns[turns.length - 1];

  // Auto-scroll on new responses
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [turns.length, isLoading]);

  // Extract checklist tasks from markdown text
  const extractedTasks: PlanTaskItem[] = React.useMemo(() => {
    if (!latestTurn?.response?.content) return [];
    const text = latestTurn.response.content;
    const lines = text.split('\n');
    const tasks: PlanTaskItem[] = [];

    lines.forEach((line, index) => {
      // Matches markdown check items or bullet action items
      const checkMatch = line.match(/^[-*]\s*\[([ xX])\]\s*(.+)$/);
      const bulletMatch = line.match(/^[-*]\s*(?:\*\*(.+?)\*\*:\s*)?(.+)$/);
      const numberedMatch = line.match(/^\d+\.\s*(?:\*\*(.+?)\*\*:\s*)?(.+)$/);

      if (checkMatch) {
        tasks.push({
          id: `task-${index}`,
          title: checkMatch[2].trim(),
          completed: checkMatch[1].toLowerCase() === 'x',
        });
      } else if (line.toLowerCase().includes('task') || line.toLowerCase().includes('todo') || line.toLowerCase().includes('step') || line.toLowerCase().includes('day ') || line.toLowerCase().includes('phase ')) {
        if (bulletMatch && bulletMatch[2]?.length > 5 && bulletMatch[2].length < 120) {
          tasks.push({
            id: `task-${index}`,
            title: (bulletMatch[1] ? `${bulletMatch[1]}: ` : '') + bulletMatch[2].trim(),
            completed: false,
          });
        } else if (numberedMatch && numberedMatch[2]?.length > 5 && numberedMatch[2].length < 120) {
          tasks.push({
            id: `task-${index}`,
            title: (numberedMatch[1] ? `${numberedMatch[1]}: ` : '') + numberedMatch[2].trim(),
            completed: false,
          });
        }
      }
    });

    return tasks.slice(0, 15);
  }, [latestTurn?.response?.content]);

  const handleSend = (overrideText?: string) => {
    const textToSend = overrideText || input;
    if (!textToSend.trim() || isLoading) return;

    // Package planning context into the submission
    onSubmit(textToSend.trim(), {
      data: JSON.stringify({ category, timeframe, pacing }),
      mimeType: 'application/nexus-plan',
      name: `${category} • ${timeframe}`,
    });

    setInput('');
  };

  const toggleTask = (taskId: string) => {
    setCompletedTasks((prev) => ({
      ...prev,
      [taskId]: !prev[taskId],
    }));
  };

  const copyPlan = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadPlan = (text: string, title?: string) => {
    const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nexus_plan_${(title || 'strategy').slice(0, 20).replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const printPlan = () => {
    window.print();
  };

  const completedCount = extractedTasks.filter((t) => completedTasks[t.id]).length;
  const progressPercent = extractedTasks.length > 0 ? Math.round((completedCount / extractedTasks.length) * 100) : 0;

  return (
    <div className="h-full flex flex-col p-2 sm:p-4 lg:p-6 w-full max-w-none space-y-2.5 sm:space-y-3 overflow-hidden">
      {/* Header and Options Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-3 sm:p-3.5 shadow-sm flex-shrink-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse" />
              <h2 className="text-base sm:text-lg lg:text-xl font-bold text-slate-900 tracking-tight">AI Planner & Strategist</h2>
              <span className="text-[10px] sm:text-[11px] font-mono font-medium px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
                Interactive Planning
              </span>
            </div>
            <p className="text-slate-500 text-xs mt-0.5 hidden sm:block">
              Formulate structured itineraries, multi-phase sprints, daily time-blocks, and actionable checklists.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowOptions(!showOptions)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all cursor-pointer self-start sm:self-auto ${
              showOptions
                ? 'bg-indigo-50 border-indigo-200 text-indigo-700 shadow-sm'
                : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-600'
            }`}
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
            </svg>
            <span>{showOptions ? 'Hide Options' : 'Customize Options'}</span>
          </button>
        </div>

        {/* Category Carousel */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-2.5 scrollbar-none">
          {CATEGORY_CONFIGS.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategory(cat.id)}
              className={`flex-shrink-0 inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                category === cat.id
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm shadow-indigo-500/20'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Collapsible Advanced Options Panel */}
        {showOptions && (
          <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 animate-in fade-in duration-200">
            {/* Timeframe */}
            <div>
              <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                Timeframe / Horizon
              </label>
              <select
                value={timeframe}
                onChange={(e) => setTimeframe(e.target.value as PlannerTimeframe)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-700 outline-none focus:border-indigo-500 transition-colors"
              >
                {TIMEFRAME_OPTIONS.map((opt) => (
                  <option key={opt.id} value={opt.id}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Pacing */}
            <div>
              <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                Pacing & Intensity
              </label>
              <select
                value={pacing}
                onChange={(e) => setPacing(e.target.value as PlannerPacing)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-700 outline-none focus:border-indigo-500 transition-colors"
              >
                {PACING_OPTIONS.map((opt) => (
                  <option key={opt.id} value={opt.id}>
                    {opt.icon} {opt.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Active Mode Hint */}
            <div className="sm:col-span-2 lg:col-span-1 flex flex-col justify-center bg-indigo-50/60 border border-indigo-100 rounded-xl px-3 py-2 text-[11px] text-indigo-800">
              <span className="font-semibold">Planning Focus:</span>
              <span className="text-slate-600">
                {CATEGORY_CONFIGS.find((c) => c.id === category)?.hint}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Main Conversation & Plan Area */}
      <div className="flex-1 min-h-0 bg-white rounded-2xl border border-slate-200/90 shadow-sm flex flex-col overflow-hidden">
        {turns.length === 0 ? (
          /* Empty State: Starters and Ideas */
          <div className="flex-1 overflow-y-auto p-4 sm:p-8 flex flex-col items-center justify-center text-center">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3 shadow-sm">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
              </svg>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 mb-1">What would you like to plan?</h3>
            <p className="text-xs sm:text-sm text-slate-500 max-w-md mb-6">
              Pick a pre-configured template below or describe any schedule, vacation, project, or personal goal.
            </p>

            {/* Starter Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3.5 w-full max-w-none text-left">
              {QUICK_STARTERS.map((starter, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setCategory(starter.category);
                    setTimeframe(starter.timeframe);
                    handleSend(starter.prompt);
                  }}
                  className="p-3.5 sm:p-4 rounded-xl border border-slate-200 hover:border-indigo-300 bg-slate-50/70 hover:bg-indigo-50/40 transition-all flex flex-col justify-between group cursor-pointer"
                >
                  <div>
                    <div className="text-xs sm:text-sm font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">
                      {starter.title}
                    </div>
                    <div className="text-[11px] sm:text-xs text-slate-500 line-clamp-2 mt-1">
                      {starter.prompt}
                    </div>
                  </div>
                  <div className="mt-2.5 text-[10px] sm:text-[11px] font-mono text-indigo-600 flex items-center gap-1 font-medium">
                    <span>Generate plan</span>
                    <span>→</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          /* Active Planning Turns */
          <div className="flex-1 overflow-y-auto p-3 sm:p-5 lg:p-6 space-y-5">
            {turns.map((turn, idx) => (
              <div key={turn.id || idx} className="space-y-4">
                {/* User Prompt Message */}
                <div className="flex justify-end">
                  <div className="max-w-[85%] sm:max-w-[70%] p-3.5 sm:p-4 rounded-2xl bg-sky-500 text-white shadow-sm shadow-sky-500/15 text-xs sm:text-sm">
                    <p className="whitespace-pre-wrap">{turn.prompt}</p>
                    {turn.attachment?.name && (
                      <div className="mt-1.5 pt-1.5 border-t border-sky-400/40 text-[11px] opacity-90 font-mono">
                        Target: {turn.attachment.name}
                      </div>
                    )}
                  </div>
                </div>

                {/* Assistant Plan Response - Full Screen Width on Computer */}
                <div className="flex justify-start w-full">
                  <div className="w-full max-w-none bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-6 lg:p-8 shadow-sm space-y-4 sm:space-y-5">
                    {/* Toolbar Header for Plan */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-indigo-600" />
                        <span className="font-semibold text-slate-900 sm:text-sm">Nexus Plan & Schedule</span>
                        <span className="text-[10px] sm:text-[11px] text-slate-400 font-mono">
                          Iteration #{idx + 1}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 font-mono text-xs">
                        <button
                          type="button"
                          onClick={() => copyPlan(turn.response.content)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors flex items-center gap-1 cursor-pointer"
                          title="Copy Plan Markdown"
                        >
                          <span>{copied ? '✓ Copied' : 'Copy'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => downloadPlan(turn.response.content, turn.prompt)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors flex items-center gap-1 cursor-pointer"
                          title="Download Markdown"
                        >
                          <span>Download</span>
                        </button>
                        <button
                          type="button"
                          onClick={printPlan}
                          className="hidden sm:inline-flex px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors items-center gap-1 cursor-pointer"
                          title="Print Plan"
                        >
                          <span>Print</span>
                        </button>
                      </div>
                    </div>

                    {/* Markdown Body - Large & Highly Legible on Computer View */}
                    <div className="prose prose-sm lg:prose-base max-w-none text-slate-800 space-y-3.5 leading-relaxed text-xs sm:text-sm lg:text-[15px]">
                      {turn.response.content.split('\n\n').map((paragraph, pIdx) => {
                        if (paragraph.startsWith('### ')) {
                          return (
                            <h3 key={pIdx} className="text-sm sm:text-base lg:text-lg font-bold text-slate-900 mt-5 mb-2 border-b border-slate-100 pb-1.5">
                              {paragraph.replace('### ', '')}
                            </h3>
                          );
                        }
                        if (paragraph.startsWith('## ')) {
                          return (
                            <h2 key={pIdx} className="text-base sm:text-lg lg:text-xl font-bold text-slate-900 mt-6 mb-2.5">
                              {paragraph.replace('## ', '')}
                            </h2>
                          );
                        }
                        return (
                          <p key={pIdx} className="whitespace-pre-wrap leading-relaxed">
                            {paragraph}
                          </p>
                        );
                      })}
                    </div>

                    {/* Interactive Checklist Widget for the latest turn - Responsive Grid on Desktop */}
                    {idx === turns.length - 1 && extractedTasks.length > 0 && (
                      <div className="mt-5 pt-4 border-t border-slate-100 bg-slate-50/80 rounded-2xl p-4 sm:p-5 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-xs sm:text-sm font-bold text-slate-900">Interactive Action Checklist</span>
                            <span className="text-xs font-mono text-indigo-600 font-semibold">
                              ({completedCount}/{extractedTasks.length} Completed)
                            </span>
                          </div>
                          <span className="text-xs font-mono text-slate-500 font-semibold">
                            {progressPercent}%
                          </span>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-indigo-600 transition-all duration-300"
                            style={{ width: `${progressPercent}%` }}
                          />
                        </div>

                        {/* Checkbox Items in 2-Column Responsive Desktop Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1 max-h-72 overflow-y-auto pr-1">
                          {extractedTasks.map((task) => {
                            const isDone = completedTasks[task.id] || task.completed;
                            return (
                              <label
                                key={task.id}
                                className={`flex items-start gap-2.5 p-2.5 rounded-xl transition-colors cursor-pointer text-xs sm:text-sm select-none ${
                                  isDone ? 'bg-indigo-50/60 text-slate-400 line-through' : 'bg-white hover:bg-slate-100/90 text-slate-800 border border-slate-200/70 shadow-2xs'
                                }`}
                              >
                                <input
                                  type="checkbox"
                                  checked={isDone}
                                  onChange={() => toggleTask(task.id)}
                                  className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer w-4 h-4"
                                />
                                <span className="leading-snug">{task.title}</span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-sm flex items-center space-x-3 text-xs text-slate-500">
                  <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                  <span>Synthesizing multi-phase strategic plan...</span>
                </div>
              </div>
            )}

            <div ref={chatEndRef} />
          </div>
        )}

        {/* Quick Refine Suggestions (Available after first response) */}
        {turns.length > 0 && !isLoading && (
          <div className="px-3 pt-2 pb-1 border-t border-slate-100 bg-slate-50/50 flex items-center gap-1.5 overflow-x-auto scrollbar-none text-xs">
            <span className="text-[10px] text-slate-400 uppercase font-semibold flex-shrink-0 tracking-wider">
              Refine:
            </span>
            {REFINE_CHIPS.map((chip, i) => (
              <button
                key={i}
                onClick={() => handleSend(chip)}
                className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:border-indigo-300 text-slate-600 hover:text-indigo-600 text-[11px] transition-colors cursor-pointer"
              >
                + {chip}
              </button>
            ))}
          </div>
        )}

        {/* Input & Chat Refinement Bar */}
        <div className="p-3 sm:p-4 bg-white border-t border-slate-100 flex-shrink-0">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
              placeholder={
                turns.length === 0
                  ? "Describe what you want to plan: 'Organize a 2-week trip to Italy with budget breakdown'..."
                  : "Refine or adjust this plan: 'Make mornings lighter', 'Add a 30-min break', 'Expand day 3'..."
              }
              disabled={isLoading}
              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-slate-900 placeholder-slate-400 focus:border-indigo-500 focus:bg-white outline-none text-xs sm:text-sm min-w-0 transition-colors"
            />
            <button
              onClick={() => handleSend()}
              disabled={isLoading || !input.trim()}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-30 text-white font-medium text-xs sm:text-sm rounded-xl transition-all shadow-sm shadow-indigo-500/20 flex-shrink-0 cursor-pointer disabled:cursor-not-allowed flex items-center gap-1.5"
            >
              <span>{turns.length === 0 ? 'Generate Plan' : 'Adjust Plan'}</span>
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiPlanner;
