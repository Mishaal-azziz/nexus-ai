import React, { useState, useRef, useEffect } from 'react';
import { Conversation, FileData } from '../types';

interface CodeBuilderProps {
  conversation: Conversation | null;
  onSubmit: (prompt: string, attachment?: FileData) => void;
  isLoading: boolean;
}

const CodeBuilder: React.FC<CodeBuilderProps> = ({ conversation, onSubmit, isLoading }) => {
  const [prompt, setPrompt] = useState('');
  const [copied, setCopied] = useState(false);
  const [isWrapEnabled, setIsWrapEnabled] = useState(false);
  const [showLineNumbers, setShowLineNumbers] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  const codeContainerRef = useRef<HTMLDivElement>(null);

  const code = conversation?.turns[conversation.turns.length - 1]?.response.content || '';

  // Calculate scroll progress
  const handleScroll = () => {
    if (!codeContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = codeContainerRef.current;
    if (scrollHeight <= clientHeight) {
      setScrollProgress(100);
      return;
    }
    const progress = Math.round((scrollTop / (scrollHeight - clientHeight)) * 100);
    setScrollProgress(Math.min(100, Math.max(0, progress)));
  };

  const scrollToTop = () => {
    if (codeContainerRef.current) {
      codeContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const scrollToBottom = () => {
    if (codeContainerRef.current) {
      codeContainerRef.current.scrollTo({ top: codeContainerRef.current.scrollHeight, behavior: 'smooth' });
    }
  };

  // Scroll to top when new code arrives
  useEffect(() => {
    if (code && codeContainerRef.current) {
      codeContainerRef.current.scrollTop = 0;
      setScrollProgress(0);
    }
  }, [code]);

  const handleBuild = (samplePrompt?: string) => {
    const text = samplePrompt || prompt;
    if (!text.trim() || isLoading) return;
    onSubmit(text);
    setPrompt('');
  };

  const copyCode = () => {
    if (!cleanCode) return;
    navigator.clipboard.writeText(cleanCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadCode = () => {
    if (!cleanCode) return;
    const blob = new Blob([cleanCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nexus_code_${Date.now()}.tsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const sampleArchitectures = [
    'Secure Node.js & Express JWT Auth with Refresh Tokens & Rate Limiter',
    'Real-time WebSocket Multi-user State Synchronizer in TypeScript',
    'High Performance React Virtualized Infinite Scroll List Hook with Cache',
    'PostgreSQL Drizzle ORM Schema with Relations and Migrations',
    'Python Async Web Scraper with Proxy Rotation and Exponential Backoff',
  ];

  const cleanCode = React.useMemo(() => {
    if (!code) return '';
    let text = code.trim();

    // 1. If text contains markdown code blocks, extract only inside blocks
    const codeBlockRegex = /```(?:[a-zA-Z0-9_\-+]*\n)?([\s\S]*?)```/g;
    const matches = [...text.matchAll(codeBlockRegex)];
    if (matches.length > 0) {
      text = matches.map((m) => m[1].trim()).filter(Boolean).join('\n\n');
    }

    // 2. Filter out non-code commentary lines from top and bottom
    const lines = text.split('\n');
    let startIdx = 0;
    while (startIdx < lines.length) {
      const line = lines[startIdx].trim();
      const isPreamble = (
        /^(?:here\s+(?:is|are)|sure|certainly|below\s+is|this\s+(?:code|implementation|script)|i\s+have|note:|welcome|enjoy|as\s+requested|in\s+this)/i.test(line) ||
        /^#{1,6}\s+/.test(line)
      );
      if (isPreamble) {
        startIdx++;
      } else {
        break;
      }
    }

    let endIdx = lines.length - 1;
    while (endIdx >= startIdx) {
      const line = lines[endIdx].trim();
      const isPostamble = (
        /^(?:hope\s+this|let\s+me\s+know|feel\s+free|this\s+code|to\s+run\s+this|usage:|how\s+to\s+use|notes?:|explanation:)/i.test(line) ||
        /^#{1,6}\s+/.test(line) ||
        ((/^(?:npm\s+run|npm\s+install|node\s+|yarn\s+)/i.test(line)) && !line.includes(';') && !line.includes('{'))
      );
      if (isPostamble) {
        endIdx--;
      } else {
        break;
      }
    }

    const cleaned = lines.slice(startIdx, endIdx + 1).join('\n').trim();
    return cleaned
      .replace(/^```[a-zA-Z0-9_\-+]*\s*\n?/gm, '')
      .replace(/\n?```\s*$/gm, '')
      .trim();
  }, [code]);

  const [codeFontSize, setCodeFontSize] = useState<'sm' | 'base' | 'lg'>('base');

  const codeLines = cleanCode ? cleanCode.split('\n') : [];

  return (
    <div
      className={`h-full flex flex-col p-2 sm:p-4 lg:p-6 w-full max-w-none space-y-2 sm:space-y-2.5 overflow-hidden ${
        isFullscreen ? 'fixed inset-0 z-50 bg-[#020617] p-4 sm:p-8' : ''
      }`}
    >
      {/* Header - Compact to maximize vertical code canvas on computer screen */}
      {!isFullscreen && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 flex-shrink-0 px-1">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <h2 className="text-base sm:text-lg lg:text-xl font-bold text-slate-900 tracking-tight">
              AI Code Architect
            </h2>
            <span className="text-[10px] sm:text-[11px] font-mono font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
              Pure Code Only
            </span>
          </div>
          <p className="text-slate-500 text-xs font-mono hidden md:block">
            Strict compiler-ready code output with zero conversational chatter
          </p>
        </div>
      )}

      {/* Input Prompt Box - Compact & Expansive */}
      {!isFullscreen && (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-2.5 sm:p-3 shadow-sm flex-shrink-0">
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleBuild()}
              placeholder="Describe what to build: 'Full TypeScript REST API for user auth with rate limits'..."
              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-slate-900 placeholder-slate-400 focus:border-indigo-500 focus:bg-white outline-none font-mono text-xs sm:text-sm min-w-0 transition-colors"
              disabled={isLoading}
            />
            <button
              onClick={() => handleBuild()}
              disabled={isLoading || !prompt.trim()}
              className="bg-sky-500 hover:bg-sky-600 disabled:opacity-40 px-5 py-2 rounded-xl font-medium text-xs sm:text-sm text-white transition-all shadow-sm shadow-sky-500/20 flex items-center justify-center space-x-2 flex-shrink-0 cursor-pointer disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Synthesizing...</span>
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                  </svg>
                  <span>Generate Code</span>
                </>
              )}
            </button>
          </div>

          {/* Quick Architect Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pt-2 scrollbar-none text-xs">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider flex-shrink-0 font-medium">
              Quick:
            </span>
            {sampleArchitectures.map((sample, i) => (
              <button
                key={i}
                onClick={() => handleBuild(sample)}
                className="flex-shrink-0 px-2.5 py-0.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 text-[11px] transition-colors font-mono cursor-pointer"
              >
                {sample.slice(0, 36)}...
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Code Terminal View Container with Dedicated Prominent Scrollbars */}
      <div className="flex-1 bg-[#050811] rounded-2xl border border-white/10 overflow-hidden flex flex-col shadow-2xl min-h-0 relative w-full">
        {/* Terminal Header & Controls */}
        <div className="border-b border-white/10 px-3 sm:px-6 py-2.5 bg-[#0d1424] flex flex-wrap gap-2 justify-between items-center flex-shrink-0 z-10">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            <span className="text-xs font-mono text-cyan-300 ml-2 font-medium">architecture_output.tsx</span>
            {codeLines.length > 0 && (
              <span className="text-[10px] font-mono text-indigo-300 bg-indigo-500/10 px-2.5 py-0.5 rounded-full border border-indigo-500/20">
                {codeLines.length} lines • {scrollProgress}% scrolled
              </span>
            )}
          </div>

          {/* Right Toolbar Controls */}
          <div className="flex items-center space-x-1.5 sm:space-x-2 text-xs font-mono">
            {/* Scroll to Top */}
            <button
              onClick={scrollToTop}
              className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-all border border-white/5 flex items-center gap-1"
              title="Scroll to top of code"
            >
              <span>▲</span>
              <span className="hidden sm:inline">Top</span>
            </button>

            {/* Scroll to Bottom */}
            <button
              onClick={scrollToBottom}
              className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-all border border-white/5 flex items-center gap-1"
              title="Scroll to bottom of code"
            >
              <span>▼</span>
              <span className="hidden sm:inline">Bottom</span>
            </button>

            {/* Toggle Line Numbers */}
            <button
              onClick={() => setShowLineNumbers(!showLineNumbers)}
              className={`px-2.5 py-1 rounded-lg border transition-all ${
                showLineNumbers
                  ? 'bg-indigo-600/30 border-indigo-500/50 text-indigo-300 font-semibold'
                  : 'bg-white/5 border-white/5 text-gray-400 hover:text-white'
              }`}
              title="Toggle line numbers"
            >
              # Lines
            </button>

            {/* Toggle Word Wrap vs Horizontal Scroll */}
            <button
              onClick={() => setIsWrapEnabled(!isWrapEnabled)}
              className={`px-2.5 py-1 rounded-lg border transition-all ${
                isWrapEnabled
                  ? 'bg-indigo-600/30 border-indigo-500/50 text-indigo-300 font-semibold'
                  : 'bg-white/5 border-white/5 text-gray-400 hover:text-white'
              }`}
              title="Toggle text wrapping vs wide horizontal scrollbar"
            >
              {isWrapEnabled ? 'Wrap: ON' : 'Scroll: ON'}
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
              title={isFullscreen ? 'Exit Fullscreen' : 'Expand Fullscreen'}
            >
              {isFullscreen ? (
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-5h-4m4 0v4m0-4l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
                </svg>
              )}
            </button>

            {/* Font Size Selector for Desktop View */}
            <div className="hidden sm:flex items-center bg-white/5 rounded-lg p-0.5 border border-white/10 text-[11px] mr-1">
              <button
                onClick={() => setCodeFontSize('sm')}
                className={`px-2 py-0.5 rounded transition-colors ${codeFontSize === 'sm' ? 'bg-sky-500 text-white font-bold' : 'text-gray-400 hover:text-white'}`}
                title="Small text"
              >
                A-
              </button>
              <button
                onClick={() => setCodeFontSize('base')}
                className={`px-2 py-0.5 rounded transition-colors ${codeFontSize === 'base' ? 'bg-sky-500 text-white font-bold' : 'text-gray-400 hover:text-white'}`}
                title="Default text"
              >
                A
              </button>
              <button
                onClick={() => setCodeFontSize('lg')}
                className={`px-2 py-0.5 rounded transition-colors ${codeFontSize === 'lg' ? 'bg-sky-500 text-white font-bold' : 'text-gray-400 hover:text-white'}`}
                title="Large text"
              >
                A+
              </button>
            </div>

            {cleanCode && (
              <>
                <button
                  onClick={downloadCode}
                  className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors flex items-center space-x-1 border border-white/5 cursor-pointer"
                  title="Download clean code (.tsx)"
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  <span className="hidden sm:inline">Save</span>
                </button>

                <button
                  onClick={copyCode}
                  className="px-3.5 py-1 rounded-lg bg-sky-500 hover:bg-sky-600 text-white transition-all flex items-center space-x-1.5 font-medium shadow-sm shadow-sky-500/20 cursor-pointer"
                  title="Copy Pure Code to Clipboard"
                >
                  {copied ? (
                    <span className="text-white font-bold">Copied!</span>
                  ) : (
                    <>
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </>
            )}
          </div>
        </div>

        {/* Scrollable Code Area - Expansive Computer Screen Canvas */}
        <div
          ref={codeContainerRef}
          onScroll={handleScroll}
          className={`flex-1 overflow-x-auto overflow-y-auto p-4 sm:p-6 lg:p-8 font-mono code-custom-scrollbar select-text min-h-0 bg-[#030712] relative ${
            codeFontSize === 'sm'
              ? 'text-xs sm:text-xs leading-normal'
              : codeFontSize === 'lg'
              ? 'text-sm sm:text-base lg:text-[17px] leading-relaxed'
              : 'text-xs sm:text-sm lg:text-[15px] leading-relaxed'
          }`}
        >
          {isLoading && !code ? (
            <div className="space-y-4 opacity-60 p-4">
              <div className="flex items-center gap-2 text-indigo-400 font-mono text-xs">
                <div className="w-3 h-3 rounded-full bg-indigo-500 animate-ping" />
                <span>Architecting production code...</span>
              </div>
              <div className="h-4 bg-white/10 rounded w-3/4 animate-pulse" />
              <div className="h-4 bg-white/10 rounded w-1/2 animate-pulse" />
              <div className="h-4 bg-white/10 rounded w-5/6 animate-pulse" />
              <div className="h-4 bg-white/10 rounded w-2/3 animate-pulse" />
              <div className="h-4 bg-white/10 rounded w-4/5 animate-pulse" />
            </div>
          ) : code ? (
            <div className={`flex min-w-full ${isWrapEnabled ? 'whitespace-pre-wrap break-words' : 'whitespace-pre'}`}>
              {showLineNumbers && (
                <div className="select-none pr-4 text-right text-gray-600 border-r border-white/10 mr-4 font-mono text-xs leading-relaxed flex-shrink-0">
                  {codeLines.map((_, i) => (
                    <div key={i} className="hover:text-indigo-400 transition-colors">
                      {i + 1}
                    </div>
                  ))}
                </div>
              )}
              <div className="flex-1 text-cyan-100 leading-relaxed font-mono">
                {cleanCode}
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-gray-500 opacity-50 text-center py-20 space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mx-auto">
                <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                </svg>
              </div>
              <p className="text-sm font-semibold text-gray-300">Ready for Code Synthesis</p>
              <p className="text-xs uppercase tracking-widest font-mono text-gray-500">
                Enter architecture prompt above to generate code
              </p>
            </div>
          )}
        </div>

        {/* Scroll Bar Status & Navigation Footer Cue */}
        {code && (
          <div className="px-4 py-2 bg-[#090e1c] border-t border-white/10 flex items-center justify-between text-[11px] font-mono text-gray-400 flex-shrink-0">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-indigo-300">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                <span>Scrollbar Active</span>
              </span>
              <span className="text-gray-500 hidden sm:inline">
                ↕ Vertical & ↔ Horizontal scroll enabled
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Scroll progress bar */}
              <div className="w-20 sm:w-28 h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-500 rounded-full transition-all duration-150"
                  style={{ width: `${scrollProgress}%` }}
                />
              </div>
              <span className="text-gray-400">{scrollProgress}%</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CodeBuilder;
