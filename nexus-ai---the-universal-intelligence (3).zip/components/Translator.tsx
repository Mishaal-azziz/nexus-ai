import React, { useState, useRef, useMemo } from 'react';
import { Conversation, FileData } from '../types';
import { geminiService } from '../geminiService';

interface TranslatorProps {
  conversation: Conversation | null;
  onSubmit: (prompt: string, attachment?: FileData) => void;
  isLoading: boolean;
}

export interface LanguageDef {
  name: string;
  flag: string;
  region: 'Popular' | 'Europe' | 'Asia & Pacific' | 'Middle East' | 'Africa' | 'Classical';
}

export const WORLD_LANGUAGES: LanguageDef[] = [
  // Popular Global
  { name: 'Spanish', flag: '🇪🇸', region: 'Popular' },
  { name: 'French', flag: '🇫🇷', region: 'Popular' },
  { name: 'German', flag: '🇩🇪', region: 'Popular' },
  { name: 'Chinese (Simplified)', flag: '🇨🇳', region: 'Popular' },
  { name: 'Chinese (Traditional)', flag: '🇹🇼', region: 'Popular' },
  { name: 'Japanese', flag: '🇯🇵', region: 'Popular' },
  { name: 'Hindi', flag: '🇮🇳', region: 'Popular' },
  { name: 'Arabic', flag: '🇸🇦', region: 'Popular' },
  { name: 'Portuguese', flag: '🇵🇹', region: 'Popular' },
  { name: 'Russian', flag: '🇷🇺', region: 'Popular' },
  { name: 'Korean', flag: '🇰🇷', region: 'Popular' },
  { name: 'Italian', flag: '🇮🇹', region: 'Popular' },
  { name: 'Dutch', flag: '🇳🇱', region: 'Popular' },
  { name: 'Turkish', flag: '🇹🇷', region: 'Popular' },
  { name: 'Vietnamese', flag: '🇻🇳', region: 'Popular' },

  // Europe
  { name: 'Polish', flag: '🇵🇱', region: 'Europe' },
  { name: 'Ukrainian', flag: '🇺🇦', region: 'Europe' },
  { name: 'Greek', flag: '🇬🇷', region: 'Europe' },
  { name: 'Swedish', flag: '🇸🇪', region: 'Europe' },
  { name: 'Norwegian', flag: '🇳🇴', region: 'Europe' },
  { name: 'Danish', flag: '🇩🇰', region: 'Europe' },
  { name: 'Finnish', flag: '🇫🇮', region: 'Europe' },
  { name: 'Czech', flag: '🇨🇿', region: 'Europe' },
  { name: 'Romanian', flag: '🇷🇴', region: 'Europe' },
  { name: 'Hungarian', flag: '🇭🇺', region: 'Europe' },
  { name: 'Bulgarian', flag: '🇧🇬', region: 'Europe' },
  { name: 'Croatian', flag: '🇭🇷', region: 'Europe' },
  { name: 'Serbian', flag: '🇷🇸', region: 'Europe' },
  { name: 'Slovak', flag: '🇸🇰', region: 'Europe' },
  { name: 'Irish', flag: '🇮🇪', region: 'Europe' },
  { name: 'Welsh', flag: '🏴󠁧󠁢󠁷󠁬󠁳󠁿', region: 'Europe' },
  { name: 'Icelandic', flag: '🇮🇸', region: 'Europe' },
  { name: 'Lithuanian', flag: '🇱🇹', region: 'Europe' },
  { name: 'Latvian', flag: '🇱🇻', region: 'Europe' },
  { name: 'Estonian', flag: '🇪🇪', region: 'Europe' },
  { name: 'Catalan', flag: '🇪🇸', region: 'Europe' },
  { name: 'Basque', flag: '🇪🇸', region: 'Europe' },
  { name: 'Galician', flag: '🇪🇸', region: 'Europe' },
  { name: 'Albanian', flag: '🇦🇱', region: 'Europe' },
  { name: 'Macedonian', flag: '🇲🇰', region: 'Europe' },
  { name: 'Bosnian', flag: '🇧🇦', region: 'Europe' },
  { name: 'Slovenian', flag: '🇸🇮', region: 'Europe' },
  { name: 'Maltese', flag: '🇲🇹', region: 'Europe' },

  // Asia & Pacific
  { name: 'Bengali', flag: '🇧🇩', region: 'Asia & Pacific' },
  { name: 'Punjabi', flag: '🇮🇳', region: 'Asia & Pacific' },
  { name: 'Telugu', flag: '🇮🇳', region: 'Asia & Pacific' },
  { name: 'Tamil', flag: '🇮🇳', region: 'Asia & Pacific' },
  { name: 'Marathi', flag: '🇮🇳', region: 'Asia & Pacific' },
  { name: 'Urdu', flag: '🇵🇰', region: 'Asia & Pacific' },
  { name: 'Gujarati', flag: '🇮🇳', region: 'Asia & Pacific' },
  { name: 'Kannada', flag: '🇮🇳', region: 'Asia & Pacific' },
  { name: 'Malayalam', flag: '🇮🇳', region: 'Asia & Pacific' },
  { name: 'Thai', flag: '🇹🇭', region: 'Asia & Pacific' },
  { name: 'Indonesian', flag: '🇮🇩', region: 'Asia & Pacific' },
  { name: 'Malay', flag: '🇲🇾', region: 'Asia & Pacific' },
  { name: 'Filipino (Tagalog)', flag: '🇵🇭', region: 'Asia & Pacific' },
  { name: 'Burmese', flag: '🇲🇲', region: 'Asia & Pacific' },
  { name: 'Khmer', flag: '🇰🇭', region: 'Asia & Pacific' },
  { name: 'Lao', flag: '🇱🇦', region: 'Asia & Pacific' },
  { name: 'Nepali', flag: '🇳🇵', region: 'Asia & Pacific' },
  { name: 'Sinhala', flag: '🇱🇰', region: 'Asia & Pacific' },
  { name: 'Mongolian', flag: '🇲🇳', region: 'Asia & Pacific' },
  { name: 'Hawaiian', flag: '🌺', region: 'Asia & Pacific' },
  { name: 'Maori', flag: '🇳🇿', region: 'Asia & Pacific' },
  { name: 'Samoan', flag: '🇼🇸', region: 'Asia & Pacific' },

  // Middle East & Central Asia
  { name: 'Persian (Farsi)', flag: '🇮🇷', region: 'Middle East' },
  { name: 'Hebrew', flag: '🇮🇱', region: 'Middle East' },
  { name: 'Kurdish', flag: '☀️', region: 'Middle East' },
  { name: 'Pashto', flag: '🇦🇫', region: 'Middle East' },
  { name: 'Azerbaijani', flag: '🇦🇿', region: 'Middle East' },
  { name: 'Kazakh', flag: '🇰🇿', region: 'Middle East' },
  { name: 'Uzbek', flag: '🇺🇿', region: 'Middle East' },
  { name: 'Georgian', flag: '🇬🇪', region: 'Middle East' },
  { name: 'Armenian', flag: '🇦🇲', region: 'Middle East' },

  // Africa
  { name: 'Swahili', flag: '🇰🇪', region: 'Africa' },
  { name: 'Amharic', flag: '🇪🇹', region: 'Africa' },
  { name: 'Yoruba', flag: '🇳🇬', region: 'Africa' },
  { name: 'Zulu', flag: '🇿🇦', region: 'Africa' },
  { name: 'Somali', flag: '🇸🇴', region: 'Africa' },
  { name: 'Hausa', flag: '🇳🇬', region: 'Africa' },
  { name: 'Afrikaans', flag: '🇿🇦', region: 'Africa' },
  { name: 'Igbo', flag: '🇳🇬', region: 'Africa' },
  { name: 'Shona', flag: '🇿🇼', region: 'Africa' },
  { name: 'Malagasy', flag: '🇲🇬', region: 'Africa' },

  // Classical & Other
  { name: 'Latin', flag: '🏛️', region: 'Classical' },
  { name: 'Esperanto', flag: '🌐', region: 'Classical' },
];

const POPULAR_QUICK_LANGS = [
  'Spanish',
  'French',
  'German',
  'Japanese',
  'Chinese (Simplified)',
  'Hindi',
  'Arabic',
  'Italian',
  'Korean',
  'Portuguese',
  'Russian',
  'Turkish',
  'Dutch',
  'Vietnamese',
  'Polish',
  'Swedish',
];

const MULTI_LANG_TARGETS = [
  'Spanish',
  'French',
  'German',
  'Japanese',
  'Chinese (Simplified)',
  'Arabic',
  'Hindi',
  'Italian',
];

const Translator: React.FC<TranslatorProps> = ({ conversation, onSubmit, isLoading }) => {
  const [text, setText] = useState('');
  const [targetLang, setTargetLang] = useState('Spanish');
  const [attachment, setAttachment] = useState<FileData | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [langSearch, setLangSearch] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // Multi-Language Simultaneous Translation State
  const [showMultiGrid, setShowMultiGrid] = useState(false);
  const [multiTranslations, setMultiTranslations] = useState<Array<{ language: string; translation: string }>>([]);
  const [isMultiLoading, setIsMultiLoading] = useState(false);
  const [copiedMultiIndex, setCopiedMultiIndex] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const translated = conversation?.turns[conversation.turns.length - 1]?.response?.content || '';

  // Filtered languages based on search query
  const filteredLanguages = useMemo(() => {
    if (!langSearch.trim()) return WORLD_LANGUAGES;
    const q = langSearch.toLowerCase().trim();
    return WORLD_LANGUAGES.filter(
      (l) => l.name.toLowerCase().includes(q) || l.region.toLowerCase().includes(q)
    );
  }, [langSearch]);

  const handleTranslate = (overrideText?: string, overrideLang?: string) => {
    const finalInput = overrideText || text;
    const finalLang = overrideLang || targetLang;

    if (!finalInput.trim() && !attachment) return;

    const finalAttachment = attachment
      ? { ...attachment, targetLang: finalLang }
      : { data: '', mimeType: '', name: '', targetLang: finalLang };

    onSubmit(finalInput, finalAttachment);

    // If multi grid is active, also trigger multi-language fetch
    if (showMultiGrid && finalInput.trim()) {
      fetchMultiTranslations(finalInput.trim());
    }
  };

  const handleSwitchLanguage = (langName: string) => {
    setTargetLang(langName);
    setIsDropdownOpen(false);
    setLangSearch('');

    // If there is already text typed or previously translated, auto-translate immediately into this language!
    if (text.trim() || translated) {
      const textToTranslate = text.trim() || conversation?.turns[conversation.turns.length - 1]?.prompt || '';
      if (textToTranslate) {
        handleTranslate(textToTranslate, langName);
      }
    }
  };

  const fetchMultiTranslations = async (textToTranslate: string) => {
    if (!textToTranslate.trim() || isMultiLoading) return;
    setIsMultiLoading(true);
    try {
      const results = await geminiService.translateMulti(textToTranslate, MULTI_LANG_TARGETS);
      setMultiTranslations(results);
    } catch (e) {
      console.error('Multi translate error:', e);
    } finally {
      setIsMultiLoading(false);
    }
  };

  const toggleMultiGrid = () => {
    const nextState = !showMultiGrid;
    setShowMultiGrid(nextState);
    if (nextState && (text.trim() || translated)) {
      const textToTranslate = text.trim() || conversation?.turns[conversation.turns.length - 1]?.prompt || '';
      if (textToTranslate) {
        fetchMultiTranslations(textToTranslate);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachment({
          data: reader.result as string,
          mimeType: file.type,
          name: file.name,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const startVoiceInput = () => {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      setNotice('Voice recognition is not supported in this browser.');
      setTimeout(() => setNotice(null), 3000);
      return;
    }

    const recognition = new SpeechRec();
    recognition.lang = 'en-US';
    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onerror = () => setIsRecording(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results?.[0]?.[0]?.transcript;
      if (transcript) {
        setText(transcript);
        handleTranslate(transcript);
      }
    };
    recognition.start();
  };

  const speak = (content: string, langName?: string) => {
    if (!('speechSynthesis' in window) || !content) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(content);
    // Find matching language code if possible
    window.speechSynthesis.speak(u);
  };

  const copyTranslation = (contentToCopy: string) => {
    if (!contentToCopy) return;
    navigator.clipboard.writeText(contentToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyMultiItem = (content: string, idx: number) => {
    navigator.clipboard.writeText(content);
    setCopiedMultiIndex(idx);
    setTimeout(() => setCopiedMultiIndex(null), 2000);
  };

  const activeLangObj = WORLD_LANGUAGES.find((l) => l.name === targetLang) || {
    name: targetLang,
    flag: '🌐',
    region: 'Popular' as const,
  };

  return (
    <div className="h-full flex flex-col p-2 sm:p-4 lg:p-6 w-full max-w-none space-y-3 overflow-hidden select-none">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 flex-shrink-0 px-1">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-teal-500 animate-pulse" />
          <h2 className="text-base sm:text-lg lg:text-xl font-bold text-slate-900 tracking-tight">
            Universal Translator
          </h2>
          <span className="text-[10px] sm:text-[11px] font-mono font-medium px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-100">
            {WORLD_LANGUAGES.length}+ Languages
          </span>
        </div>

        {/* Action Toggle for Multi-Language Grid */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={toggleMultiGrid}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
              showMultiGrid
                ? 'bg-teal-50 border-teal-200 text-teal-700 shadow-sm'
                : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            <span>🌐</span>
            <span>{showMultiGrid ? 'Hide Multi-Language Grid' : 'Translate to 8 Languages at Once'}</span>
          </button>
        </div>
      </div>

      {notice && (
        <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 text-center animate-in fade-in flex-shrink-0">
          {notice}
        </div>
      )}

      {/* Main Translation Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4 flex-1 min-h-0 overflow-y-auto">
        {/* Source Input Box */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-sm flex flex-col justify-between space-y-3 min-h-[260px]">
          {/* Top Bar for Source Box */}
          <div className="flex justify-between items-center pb-2.5 border-b border-slate-100">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              Source Text (Auto-Detect)
            </span>
            <div className="flex items-center space-x-1.5">
              <button
                onClick={startVoiceInput}
                className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                  isRecording
                    ? 'bg-red-50 text-red-600 border border-red-200 animate-pulse'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
                }`}
                title="Voice Input"
                aria-label="Speak into microphone"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </button>
              <input
                type="file"
                className="hidden"
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept="image/*,application/pdf,text/*"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                  attachment
                    ? 'bg-teal-50 border border-teal-200 text-teal-700'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
                }`}
                title="Attach Document or Image to Translate"
                aria-label="Upload document"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                </svg>
              </button>
            </div>
          </div>

          {/* Textarea */}
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                handleTranslate();
              }
            }}
            placeholder={
              isRecording
                ? 'Listening for speech input...'
                : 'Enter words, sentences, or paragraphs to translate (Press Ctrl+Enter to translate)...'
            }
            className="flex-1 w-full bg-transparent border-none text-slate-900 placeholder-slate-400 resize-none focus:ring-0 outline-none text-sm sm:text-base leading-relaxed font-normal min-h-[140px]"
            disabled={isLoading}
          />

          {attachment && (
            <div className="p-2.5 bg-teal-50/70 border border-teal-100 rounded-xl flex items-center justify-between text-xs text-teal-800">
              <span className="truncate font-medium">{attachment.name}</span>
              <button
                onClick={() => setAttachment(null)}
                className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}

          {/* Bottom Bar with Counter & Translate Button */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
            <div className="flex items-center gap-3 text-slate-400">
              <span>{text.length} chars</span>
              {text && (
                <button
                  type="button"
                  onClick={() => speak(text)}
                  className="hover:text-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                  </svg>
                  <span>Listen</span>
                </button>
              )}
            </div>

            <button
              onClick={() => handleTranslate()}
              disabled={isLoading || (!text.trim() && !attachment)}
              className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-medium text-xs shadow-sm shadow-teal-600/20 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Translating...</span>
                </>
              ) : (
                <>
                  <span>Translate</span>
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Target Output Box with Expanded Languages */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-5 shadow-sm flex flex-col justify-between space-y-3 min-h-[260px] relative">
          {/* Language Selection Header */}
          <div className="flex flex-col space-y-2 pb-2.5 border-b border-slate-100 flex-shrink-0">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Target Language
              </span>

              {/* Comprehensive Searchable Language Picker Dropdown */}
              <div className="relative" ref={dropdownRef}>
                <button
                  type="button"
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-800 transition-colors cursor-pointer"
                >
                  <span className="text-sm">{activeLangObj.flag}</span>
                  <span>{activeLangObj.name}</span>
                  <svg className="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {/* Dropdown Menu of 85+ Languages with Search Filter */}
                {isDropdownOpen && (
                  <div className="absolute right-0 top-full mt-1.5 w-72 sm:w-80 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-2.5 space-y-2 animate-in fade-in zoom-in-95 duration-150">
                    <div className="relative">
                      <input
                        type="text"
                        value={langSearch}
                        onChange={(e) => setLangSearch(e.target.value)}
                        placeholder="Search 85+ languages..."
                        autoFocus
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs outline-none focus:border-teal-500 transition-colors"
                      />
                      {langSearch && (
                        <button
                          onClick={() => setLangSearch('')}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                        >
                          ✕
                        </button>
                      )}
                    </div>

                    <div className="max-h-64 overflow-y-auto space-y-0.5 pr-1 scrollbar-thin">
                      {filteredLanguages.length === 0 ? (
                        <div className="text-center py-4 text-xs text-slate-400">
                          No matching language found
                        </div>
                      ) : (
                        filteredLanguages.map((l) => (
                          <button
                            key={l.name}
                            type="button"
                            onClick={() => handleSwitchLanguage(l.name)}
                            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs transition-colors cursor-pointer text-left ${
                              targetLang === l.name
                                ? 'bg-teal-50 text-teal-800 font-semibold'
                                : 'text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <span className="flex items-center gap-2">
                              <span className="text-sm">{l.flag}</span>
                              <span>{l.name}</span>
                            </span>
                            <span className="text-[10px] text-slate-400 uppercase font-mono">
                              {l.region}
                            </span>
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Quick-Switch Language Chips Carousel - Instantly tap any to switch and translate */}
            <div className="flex items-center gap-1 overflow-x-auto pt-1 scrollbar-none text-xs">
              <span className="text-[10px] text-slate-400 uppercase font-semibold flex-shrink-0 tracking-wider">
                Quick:
              </span>
              {POPULAR_QUICK_LANGS.map((langName) => {
                const langObj = WORLD_LANGUAGES.find((l) => l.name === langName);
                const isSelected = targetLang === langName;
                return (
                  <button
                    key={langName}
                    type="button"
                    onClick={() => handleSwitchLanguage(langName)}
                    className={`flex-shrink-0 inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-teal-600 text-white font-semibold shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    <span>{langObj?.flag}</span>
                    <span>{langName.split(' ')[0]}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Primary Translated Output */}
          <div className="flex-1 flex flex-col justify-between min-h-[140px] relative">
            {translated ? (
              <div className="space-y-3">
                <p className="text-slate-900 text-base sm:text-lg lg:text-xl leading-relaxed font-medium whitespace-pre-wrap select-text">
                  {translated}
                </p>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 py-8 text-center space-y-1">
                <svg className="w-8 h-8 text-slate-300 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5c1.382 3.307 3.454 6.333 5.67 9" />
                </svg>
                <p className="text-xs font-medium">Translation will appear here</p>
                <p className="text-[11px] text-slate-400">Select any target language above to translate</p>
              </div>
            )}

            {/* Translation Loading Overlay */}
            {isLoading && (
              <div className="absolute inset-0 bg-white/80 backdrop-blur-xs rounded-xl flex items-center justify-center space-x-2.5">
                <div className="w-5 h-5 border-2 border-teal-600 border-t-transparent rounded-full animate-spin" />
                <span className="text-xs font-semibold text-teal-800">Translating to {targetLang}...</span>
              </div>
            )}
          </div>

          {/* Output Controls & Quick-Translate to Other Languages */}
          {translated && (
            <div className="pt-2 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between text-xs">
                {/* Switch to Other Popular Languages One-Click */}
                <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold flex-shrink-0">
                    Translate to:
                  </span>
                  {['French', 'German', 'Japanese', 'Arabic', 'Hindi', 'Italian', 'Russian']
                    .filter((l) => l !== targetLang)
                    .slice(0, 4)
                    .map((otherLang) => (
                      <button
                        key={otherLang}
                        type="button"
                        onClick={() => handleSwitchLanguage(otherLang)}
                        className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-teal-50 hover:text-teal-700 text-slate-600 text-[11px] transition-colors cursor-pointer flex-shrink-0"
                      >
                        {otherLang}
                      </button>
                    ))}
                </div>

                {/* Speak and Copy Actions */}
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => speak(translated, targetLang)}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                    title="Pronounce translation"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                    </svg>
                  </button>
                  <button
                    type="button"
                    onClick={() => copyTranslation(translated)}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer flex items-center gap-1 font-medium"
                    title="Copy to clipboard"
                  >
                    {copied ? (
                      <span className="text-[11px] text-teal-700 font-semibold">✓ Copied</span>
                    ) : (
                      <>
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Multi-Language Simultaneous Grid (When active) */}
      {showMultiGrid && (
        <div className="bg-white rounded-2xl border border-teal-200/80 p-4 sm:p-5 shadow-sm space-y-3 flex-shrink-0 animate-in fade-in duration-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-sm">🌐</span>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900">
                Translations in 8 Top Global Languages
              </h3>
              <span className="text-[10px] font-mono text-teal-700 bg-teal-50 px-2 py-0.5 rounded-full border border-teal-100">
                Simultaneous
              </span>
            </div>

            <button
              type="button"
              onClick={() => {
                const queryText = text.trim() || conversation?.turns[conversation.turns.length - 1]?.prompt || '';
                if (queryText) fetchMultiTranslations(queryText);
              }}
              disabled={isMultiLoading || (!text.trim() && !translated)}
              className="text-xs text-teal-700 hover:text-teal-800 font-medium flex items-center gap-1 cursor-pointer disabled:opacity-40"
            >
              <span>{isMultiLoading ? 'Translating...' : '↻ Refresh Grid'}</span>
            </button>
          </div>

          {isMultiLoading ? (
            <div className="py-8 flex items-center justify-center space-x-2 text-xs text-teal-700">
              <div className="w-4 h-4 border-2 border-teal-600 border-t-transparent rounded-full animate-spin" />
              <span>Translating into 8 languages concurrently...</span>
            </div>
          ) : multiTranslations.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
              {multiTranslations.map((item, idx) => {
                const langDef = WORLD_LANGUAGES.find((l) => l.name.toLowerCase().includes(item.language.toLowerCase())) || {
                  flag: '🌐',
                  name: item.language,
                };
                return (
                  <div
                    key={idx}
                    className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl space-y-1.5 flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1.5 font-semibold text-slate-800">
                        <span>{langDef.flag}</span>
                        <span>{item.language}</span>
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => speak(item.translation)}
                          className="p-1 hover:text-teal-700 text-slate-400 cursor-pointer"
                          title="Listen"
                        >
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                          </svg>
                        </button>
                        <button
                          type="button"
                          onClick={() => copyMultiItem(item.translation, idx)}
                          className="p-1 hover:text-teal-700 text-slate-400 cursor-pointer"
                          title="Copy"
                        >
                          {copiedMultiIndex === idx ? (
                            <span className="text-[10px] text-teal-700 font-bold">✓</span>
                          ) : (
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                            </svg>
                          )}
                        </button>
                      </div>
                    </div>
                    <p className="text-xs sm:text-sm font-medium text-slate-900 select-text leading-snug">
                      {item.translation}
                    </p>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-6 text-center text-xs text-slate-400">
              Enter any word or sentence above and click Translate to see it in 8 languages at once.
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Translator;
