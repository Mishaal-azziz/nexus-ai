
export enum AppMode {
  DASHBOARD = 'DASHBOARD',
  CHAT = 'CHAT',
  PLANNER = 'PLANNER', // AI Planner & Schedule Strategist
  CODE = 'CODE',
  TRANSLATE = 'TRANSLATE',
  SEARCH = 'SEARCH', // Advanced Chat with live web grounding
  STEM = 'STEM',
  AI_TUTOR = 'AI_TUTOR',
}

export enum PlannerCategory {
  DAILY_SCHEDULE = 'Daily Schedule',
  PROJECT_ROADMAP = 'Project Roadmap',
  STUDY_EXAM = 'Study & Exam Sprint',
  TRAVEL_ITINERARY = 'Travel & Itinerary',
  FITNESS_MEAL = 'Fitness & Nutrition',
  EVENT_PARTY = 'Event & Launch',
  BUDGET_FINANCE = 'Budget & Financial Goal',
  CUSTOM = 'Custom Strategy',
}

export enum PlannerTimeframe {
  TODAY = '24-Hour Schedule',
  WEEK_SPRINT = '7-Day Sprint',
  MONTH = '30-Day Plan',
  QUARTER = 'Quarterly Milestones',
  LONG_TERM = 'Long-Term Roadmap',
}

export enum PlannerPacing {
  INTENSIVE = 'High Intensity / Fast Track',
  BALANCED = 'Balanced & Sustainable',
  RELAXED = 'Gentle & Low Stress',
}

export interface PlanTaskItem {
  id: string;
  title: string;
  timeOrPhase?: string;
  completed?: boolean;
  priority?: 'high' | 'medium' | 'low';
}

export enum TutorSubject {
  MATH = 'Mathematics',
  SCIENCE = 'Science',
  HISTORY = 'History',
  LITERATURE = 'Literature',
  GEOGRAPHY = 'Geography',
}

export enum StemSubMode {
  GENERAL = 'General',
  MATH = 'Mathematics',
  PHYSICS = 'Physics',
  CHEMISTRY = 'Chemistry',
  BIOLOGY = 'Biology',
  CS = 'Computer Science',
  ENGINEERING = 'Engineering',
}

export interface HistoryTurn {
    id: string;
    prompt: string;
    attachment?: FileData;
    response: ChatMessage;
}

export interface Conversation {
    id:string;
    title: string;
    mode: AppMode;
    turns: HistoryTurn[];
    createdAt: number;
    // For modes with sub-settings
    subMode?: StemSubMode | TutorSubject;
    grade?: number;
}

export interface ChatMessage {
  id: string;
  role: 'assistant';
  content: string; // The primary text response
  type: 'text' | 'image' | 'code' | 'links' | 'translation' | 'stem' | 'tutor' | 'quiz' | 'builder' | 'plan' | 'error';
  metadata?: any;
}

export interface AiAppInputDef {
  key: string;
  label: string;
  placeholder: string;
  type: 'text' | 'textarea' | 'select';
  options?: string[];
}

export interface AiAppBlueprint {
  id: string;
  name: string;
  tagline: string;
  systemInstruction: string;
  starterMessage: string;
  inputs: AiAppInputDef[];
  sampleTestQueries: string[];
  codeSnippet: string;
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface StoryPage {
  text: string;
  imageUrl?: string;
}

export interface FileData {
  data: string;
  mimeType: string;
  name: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
}
