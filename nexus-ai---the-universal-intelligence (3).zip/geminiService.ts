import { FileData, QuizQuestion, StemSubMode, AiAppBlueprint } from './types';

async function fetchApi<T>(endpoint: string, body: any): Promise<T> {
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    let errorMsg = `HTTP Error ${res.status}`;
    try {
      const errorJson = await res.json();
      if (errorJson.error) errorMsg = errorJson.error;
    } catch {}
    throw new Error(errorMsg);
  }

  return res.json();
}

export const geminiService = {
  async generateTitle(prompt: string): Promise<string> {
    try {
      const data = await fetchApi<{ title: string }>('/api/title', { prompt });
      return data.title || 'Nexus Session';
    } catch (e) {
      console.error('Title generation fallback:', e);
      return prompt.slice(0, 24) || 'New Conversation';
    }
  },

  async chat(message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[] = []) {
    const data = await fetchApi<{ text: string }>('/api/chat', { prompt: message, history });
    return {
      text: data.text,
      candidates: [
        {
          content: { parts: [{ text: data.text }] },
        },
      ],
    };
  },

  async search(query: string, attachment?: FileData) {
    const data = await fetchApi<{
      text: string;
      links: Array<{ uri: string; title: string }>;
      rawChunks?: any[];
      searchQueries?: string[];
    }>('/api/search', { query, attachment });

    return {
      text: data.text,
      links: data.links || [],
      candidates: [
        {
          groundingMetadata: {
            groundingChunks: (data.links || []).map(l => ({
              web: { uri: l.uri, title: l.title },
            })),
            webSearchQueries: data.searchQueries || [],
          },
        },
      ],
    };
  },

  async generateImage(prompt: string, options?: { aspectRatio?: string; negativePrompt?: string; style?: string }): Promise<string> {
    const data = await fetchApi<{ imageUrl: string }>('/api/image', {
      prompt,
      aspectRatio: options?.aspectRatio || '1:1',
      negativePrompt: options?.negativePrompt,
      style: options?.style,
    });
    return data.imageUrl;
  },

  async enhanceImagePrompt(prompt: string, style?: string): Promise<string> {
    try {
      const data = await fetchApi<{ enhancedPrompt: string }>('/api/image/enhance', { prompt, style });
      return data.enhancedPrompt || prompt;
    } catch {
      return prompt;
    }
  },

  async plan(params: {
    prompt: string;
    category?: string;
    timeframe?: string;
    pacing?: string;
    history?: any[];
  }): Promise<{ planText: string; title?: string }> {
    const data = await fetchApi<{ planText: string; title?: string }>('/api/plan', params);
    return data;
  },

  async translate(text: string, targetLang: string, attachment?: FileData): Promise<string> {
    const data = await fetchApi<{ translation: string }>('/api/translate', {
      text,
      targetLang,
      attachment,
    });
    return data.translation;
  },

  async translateMulti(
    text: string,
    targetLangs?: string[]
  ): Promise<Array<{ language: string; translation: string }>> {
    const data = await fetchApi<{ translations: Array<{ language: string; translation: string }> }>(
      '/api/translate/multi',
      { text, targetLangs }
    );
    return data.translations || [];
  },

  async architectCode(prompt: string): Promise<string> {
    const data = await fetchApi<{ code: string }>('/api/code', { prompt });
    return data.code;
  },

  async solveStem(prompt: string, subject: string, grade: number): Promise<string> {
    const data = await fetchApi<{ solution: string }>('/api/stem', {
      prompt,
      subject,
      grade,
    });
    return data.solution;
  },

  async tutor(prompt: string, subject: string, grade: number): Promise<string> {
    const data = await fetchApi<{ text: string }>('/api/tutor', {
      prompt,
      subject,
      grade,
      type: 'chat',
    });
    return data.text;
  },

  async generateQuiz(subject: string, grade: number, topic: string): Promise<QuizQuestion[]> {
    const data = await fetchApi<{ quiz: QuizQuestion[] }>('/api/tutor', {
      prompt: topic,
      subject,
      grade,
      type: 'quiz',
    });
    return data.quiz || [];
  },

  async buildAiApp(prompt: string): Promise<AiAppBlueprint> {
    const data = await fetchApi<AiAppBlueprint>('/api/builder', {
      action: 'build',
      prompt,
    });
    return data;
  },

  async runAiApp(
    systemInstruction: string,
    userMessage: string,
    variables?: Record<string, string>
  ): Promise<string> {
    const data = await fetchApi<{ text: string }>('/api/builder', {
      action: 'run',
      systemInstruction,
      userMessage,
      variables,
    });
    return data.text;
  },
};
