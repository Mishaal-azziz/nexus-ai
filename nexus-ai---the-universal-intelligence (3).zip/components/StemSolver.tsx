import React, { useState } from 'react';
import { StemSubMode, Conversation, FileData } from '../types';

interface StemSolverProps {
  subMode: StemSubMode;
  grade: number;
  conversation: Conversation | null;
  onSubmit: (prompt: string, attachment?: FileData) => void;
  isLoading: boolean;
}

const StemSolver: React.FC<StemSolverProps> = ({
  subMode,
  grade,
  conversation,
  onSubmit,
  isLoading,
}) => {
  const [prompt, setPrompt] = useState('');
  const [copied, setCopied] = useState(false);

  const latestResponse = conversation?.turns[conversation.turns.length - 1]?.response;
  const output = latestResponse?.type === 'stem' ? latestResponse.content : '';

  const handleSolve = (samplePrompt?: string) => {
    const text = samplePrompt || prompt;
    if (!text.trim() || isLoading) return;
    onSubmit(text, { data: 'solve', mimeType: '', name: '' });
    setPrompt('');
  };

  const copySolution = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const sampleProblems: Record<string, string[]> = {
    [StemSubMode.MATH]: [
      'Find the derivative of f(x) = (3x^2 - 5) / (2x + 1)',
      'Calculate the area between curves y = x^2 and y = 4',
      'Solve the system: 2x + 3y = 12 and 4x - y = 5',
    ],
    [StemSubMode.PHYSICS]: [
      'A 1200kg car accelerates from rest to 25m/s in 6 seconds. Calculate net work done.',
      'A projectile is launched at 30 m/s at an angle of 45°. Find the maximum height and range.',
      'Explain Snell’s Law and calculate refraction from air (n=1) to water (n=1.33) at 30°.',
    ],
    [StemSubMode.CHEMISTRY]: [
      'Balance the reaction: C3H8 + O2 -> CO2 + H2O and calculate moles of O2 needed for 44g propane.',
      'Calculate the pH of a 0.05 M solution of HCl.',
      'Explain the difference between ionic and covalent bonding with examples.',
    ],
    [StemSubMode.CS]: [
      'Explain time complexity of Quicksort vs Mergesort with recurrence relations.',
      'Write a Python algorithm to detect a cycle in a linked list using Floyd’s tortoise and hare.',
      'Explain how binary search trees maintain search efficiency in O(log n).',
    ],
    default: [
      'Explain how photosynthesis converts photon energy into ATP and NADPH.',
      'Calculate gravitational potential energy of a 5kg mass lifted 10 meters on Earth.',
      'Solve quadratic equation: 3x^2 - 8x + 4 = 0 using quadratic formula step-by-step.',
    ],
  };

  const currentSamples = sampleProblems[subMode] || sampleProblems.default;

  return (
    <div className="h-full flex flex-col p-3 sm:p-6 max-w-7xl mx-auto w-full space-y-5 overflow-hidden">
      {/* Header */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full bg-lime-500/10 border border-lime-500/30 text-lime-400 text-xs font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-lime-400 animate-pulse" />
          <span>REASONING MODALITY • GRADE {grade}</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-black bg-gradient-to-r from-lime-400 via-emerald-300 to-cyan-400 bg-clip-text text-transparent tracking-tight">
          {subMode} Problem Solver
        </h2>
        <p className="text-gray-400 text-xs sm:text-sm">
          Step-by-step mathematical proofs, theoretical derivations, and structured solutions.
        </p>
      </div>

      {/* Main Grid: Input and Computed Solution */}
      <div className="flex-1 grid lg:grid-cols-2 gap-4 sm:gap-6 min-h-0 overflow-y-auto pr-1">
        {/* Left Column: Input Problem */}
        <div className="flex flex-col space-y-3 bg-[#12192e]/90 border border-white/10 rounded-3xl p-4 sm:p-6 backdrop-blur-xl shadow-xl">
          <label className="text-[10px] sm:text-xs text-lime-300 uppercase font-black tracking-widest px-1">
            Problem Statement / Mathematical Equation
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={`Enter a ${subMode} equation or question...`}
            className="flex-1 bg-transparent border-none text-gray-100 resize-none focus:ring-0 outline-none text-base sm:text-lg leading-relaxed font-light min-h-[140px]"
            disabled={isLoading}
          />

          {/* Quick Problem Templates */}
          <div className="space-y-1.5 pt-2 border-t border-white/5">
            <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider">
              Example Problems:
            </span>
            <div className="space-y-1">
              {currentSamples.map((sample, i) => (
                <button
                  key={i}
                  onClick={() => handleSolve(sample)}
                  className="w-full text-left text-xs p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-lime-300 transition-colors truncate"
                  title={sample}
                >
                  &bull; {sample}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => handleSolve()}
            disabled={isLoading || !prompt.trim()}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-lime-600 to-emerald-600 hover:from-lime-500 hover:to-emerald-500 disabled:opacity-40 text-white font-bold text-sm tracking-wider uppercase transition-all shadow-lg shadow-lime-600/20 flex items-center justify-center space-x-2"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Computing Derivation...</span>
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
                <span>Solve Problem</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Computed Output */}
        <div className="flex flex-col bg-[#0b101e]/90 border border-white/10 rounded-3xl overflow-hidden shadow-xl min-h-[220px]">
          <div className="flex items-center justify-between p-4 border-b border-white/5 bg-black/20">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <label className="text-[10px] text-cyan-300 uppercase font-black tracking-widest">
                Computed Solution & Rationale
              </label>
            </div>
            {output && (
              <button
                onClick={copySolution}
                className="text-xs px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors"
              >
                {copied ? 'Copied!' : 'Copy'}
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-4 sm:p-6 scrollbar-thin">
            {isLoading && !output ? (
              <div className="flex flex-col items-center justify-center h-full py-12 space-y-3 opacity-70">
                <div className="w-10 h-10 border-3 border-lime-400 border-t-transparent rounded-full animate-spin" />
                <p className="text-xs font-mono text-lime-300 uppercase tracking-widest">
                  Computing step-by-step proof...
                </p>
              </div>
            ) : output ? (
              <div className="text-sm leading-relaxed text-gray-100 whitespace-pre-wrap font-sans">
                {output}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-gray-500 opacity-40 text-center py-16">
                <svg className="w-12 h-12 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
                <p className="text-sm uppercase tracking-widest font-mono">Awaiting STEM Problem</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StemSolver;
