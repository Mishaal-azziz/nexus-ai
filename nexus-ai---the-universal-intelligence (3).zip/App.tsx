import React, { useState, useEffect } from 'react';
import { AppMode, StemSubMode, Conversation, HistoryTurn, FileData } from './types';
import { geminiService } from './geminiService';
import Sidebar from './components/Sidebar';
import ChatInterface from './components/ChatInterface';
import AiPlanner from './components/AiPlanner';
import CodeBuilder from './components/CodeBuilder';
import Translator from './components/Translator';
import SearchProvider from './components/SearchProvider';
import SurpriseIntro from './components/SurpriseIntro';
import Dashboard from './components/Dashboard';
import StemSolver from './components/StemSolver';
import GradeSelector from './components/GradeSelector';
import AiTutor from './components/AiTutor';
import WelcomeScreen from './components/WelcomeScreen';

const App: React.FC = () => {
  // Start on Home / Welcome screen by default so animation and home button are immediately visible
  const [isEntered, setIsEntered] = useState<boolean>(false);

  const [mode, setMode] = useState<AppMode>(AppMode.DASHBOARD);
  const [stemSubMode, setStemSubMode] = useState<StemSubMode>(StemSubMode.GENERAL);
  const [showIntro, setShowIntro] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const saved = localStorage.getItem('nexus-conversations');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('nexus-conversations', JSON.stringify(conversations));
  }, [conversations]);

  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);

  // 3-Second Loading Animation State when returning to Home
  const [isNavigatingHome, setIsNavigatingHome] = useState(false);
  const [homeProgress, setHomeProgress] = useState(0);
  const [homeStatusText, setHomeStatusText] = useState('Saving workspace state...');

  const activeConversation = conversations.find((c) => c.id === activeConversationId);

  // Grade selection for STEM & AI Tutor
  const [grades, setGrades] = useState<{ [key: string]: number }>({
    [AppMode.STEM]: 10,
    [AppMode.AI_TUTOR]: 10,
  });
  const [isGradeSelectorVisible, setIsGradeSelectorVisible] = useState(false);

  const handleGradeSelect = (grade: number) => {
    if (mode === AppMode.STEM || mode === AppMode.AI_TUTOR) {
      setGrades((prev) => ({ ...prev, [mode]: grade }));
      setIsGradeSelectorVisible(false);
    }
  };

  const handleSetMode = (newMode: AppMode) => {
    setMode(newMode);
    setActiveConversationId(null);
    setIsMobileMenuOpen(false);
  };

  const handleSelectConversation = (id: string) => {
    setActiveConversationId(id);
    const convo = conversations.find((c) => c.id === id);
    if (convo?.subMode) setStemSubMode(convo.subMode as StemSubMode);
    setIsMobileMenuOpen(false);
  };

  const addOrUpdateTurn = (convoId: string, turn: HistoryTurn) => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === convoId) {
          const existingTurnIndex = c.turns.findIndex((t) => t.id === turn.id);
          if (existingTurnIndex > -1) {
            const newTurns = [...c.turns];
            newTurns[existingTurnIndex] = turn;
            return { ...c, turns: newTurns };
          }
          return { ...c, turns: [...c.turns, turn] };
        }
        return c;
      })
    );
  };

  const handleNewConversation = async (prompt: string, attachment?: FileData): Promise<string> => {
    const title = await geminiService.generateTitle(prompt);
    const newConversation: Conversation = {
      id: Date.now().toString(),
      title,
      mode,
      turns: [],
      createdAt: Date.now(),
      grade: mode === AppMode.STEM || mode === AppMode.AI_TUTOR ? grades[mode] : undefined,
      subMode: mode === AppMode.STEM ? stemSubMode : undefined,
    };
    setConversations((prev) => [newConversation, ...prev]);
    setActiveConversationId(newConversation.id);
    return newConversation.id;
  };

  const handleSubmit = async (prompt: string, attachment?: FileData) => {
    setIsLoading(true);
    let convoId = activeConversationId;
    if (!convoId) {
      convoId = await handleNewConversation(prompt, attachment);
    }

    const turnId = Date.now().toString();

    try {
      let response: any;
      switch (mode) {
        case AppMode.CHAT: {
          const history =
            conversations
              .find((c) => c.id === convoId)
              ?.turns.flatMap((t) => [
                { role: 'user' as const, parts: [{ text: t.prompt }] },
                { role: 'model' as const, parts: [{ text: t.response.content }] },
              ]) || [];
          response = await geminiService.chat(prompt, history);
          addOrUpdateTurn(convoId, {
            id: turnId,
            prompt,
            attachment,
            response: {
              id: turnId + 'r',
              role: 'assistant',
              content: response.text,
              type: 'text',
            },
          });
          break;
        }

        case AppMode.SEARCH: {
          response = await geminiService.search(prompt, attachment);
          const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
          const formattedChunks = (response.links && response.links.length > 0)
            ? response.links.map((l: any) => ({ web: { uri: l.uri, title: l.title } }))
            : rawChunks;

          addOrUpdateTurn(convoId, {
            id: turnId,
            prompt,
            attachment,
            response: {
              id: turnId + 'r',
              role: 'assistant',
              content: response.text,
              type: 'links',
              metadata: {
                chunks: formattedChunks,
              },
            },
          });
          break;
        }

        case AppMode.PLANNER: {
          let category = 'Daily Schedule';
          let timeframe = '7-Day Sprint';
          let pacing = 'Balanced & Sustainable';

          if (attachment?.data) {
            try {
              const parsed = JSON.parse(attachment.data);
              if (parsed.category) category = parsed.category;
              if (parsed.timeframe) timeframe = parsed.timeframe;
              if (parsed.pacing) pacing = parsed.pacing;
            } catch {}
          }

          const planResult = await geminiService.plan({
            prompt,
            category,
            timeframe,
            pacing,
            history: activeConversation?.turns.map(t => ({
              role: 'user',
              parts: [{ text: t.prompt }],
            })) || [],
          });

          addOrUpdateTurn(convoId, {
            id: turnId,
            prompt,
            attachment,
            response: {
              id: turnId + 'r',
              role: 'assistant',
              content: planResult.planText,
              type: 'plan',
              metadata: { category, timeframe, pacing },
            },
          });
          break;
        }

        case AppMode.CODE: {
          const codeResponse = await geminiService.architectCode(prompt);
          addOrUpdateTurn(convoId, {
            id: turnId,
            prompt,
            attachment,
            response: {
              id: turnId + 'r',
              role: 'assistant',
              content: codeResponse,
              type: 'code',
            },
          });
          break;
        }

        case AppMode.TRANSLATE: {
          const targetLang = (attachment as any)?.targetLang || 'Spanish';
          const translation = await geminiService.translate(prompt, targetLang, attachment);
          addOrUpdateTurn(convoId, {
            id: turnId,
            prompt,
            attachment,
            response: {
              id: turnId + 'r',
              role: 'assistant',
              content: translation,
              type: 'translation',
            },
          });
          break;
        }

        case AppMode.STEM: {
          const currentGrade = activeConversation?.grade || grades[mode] || 10;
          const solution = await geminiService.solveStem(prompt, stemSubMode, currentGrade);
          addOrUpdateTurn(convoId, {
            id: turnId,
            prompt,
            attachment,
            response: {
              id: turnId + 'r',
              role: 'assistant',
              content: solution,
              type: 'stem',
            },
          });
          break;
        }

        case AppMode.AI_TUTOR: {
          const subject = (attachment as any)?.subject || 'General';
          const currentGrade = activeConversation?.grade || grades[mode] || 10;
          const tutorResponse = await geminiService.tutor(prompt, subject, currentGrade);
          addOrUpdateTurn(convoId, {
            id: turnId,
            prompt,
            attachment,
            response: {
              id: turnId + 'r',
              role: 'assistant',
              content: tutorResponse,
              type: 'tutor',
            },
          });
          break;
        }
      }
    } catch (e: any) {
      console.error('Operation error:', e);
      addOrUpdateTurn(convoId, {
        id: turnId,
        prompt,
        attachment,
        response: {
          id: turnId + 'r',
          role: 'assistant',
          content: `Notice: ${e?.message || 'The intelligence core encountered an issue. Please try again.'}`,
          type: 'error',
          metadata: { chunks: [] },
        },
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleEnterWorkspace = () => {
    try {
      sessionStorage.setItem('nexus_entered', 'true');
    } catch {}
    setMode(AppMode.DASHBOARD);
    setIsEntered(true);
  };

  const handleReturnToWelcome = () => {
    if (isNavigatingHome) return;
    setIsNavigatingHome(true);
    setHomeProgress(0);
    setHomeStatusText('Saving workspace state...');

    const duration = 3000;
    const startTime = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.floor((elapsed / duration) * 100));
      setHomeProgress(pct);

      if (elapsed < 1100) {
        setHomeStatusText('Saving workspace state...');
      } else if (elapsed < 2200) {
        setHomeStatusText('Connecting to home screen...');
      } else {
        setHomeStatusText('Welcome to Nexus...');
      }

      if (elapsed >= duration) {
        clearInterval(interval);
        setTimeout(() => {
          try {
            sessionStorage.removeItem('nexus_entered');
          } catch {}
          setIsEntered(false);
          setIsNavigatingHome(false);
          setHomeProgress(0);
        }, 80);
      }
    }, 35);
  };

  if (!isEntered) {
    return <WelcomeScreen onEnter={handleEnterWorkspace} />;
  }

  if (showIntro) {
    return <SurpriseIntro onComplete={() => setShowIntro(false)} />;
  }

  const getTitle = () => {
    if (activeConversation) return activeConversation.title;
    switch (mode) {
      case AppMode.DASHBOARD:
        return 'Overview';
      case AppMode.CHAT:
        return 'Chatbot';
      case AppMode.SEARCH:
        return 'Advanced Search';
      case AppMode.PLANNER:
        return 'AI Planner';
      case AppMode.CODE:
        return 'Code Builder';
      case AppMode.TRANSLATE:
        return 'Translator';
      case AppMode.STEM:
        return `STEM Analysis (${stemSubMode})`;
      case AppMode.AI_TUTOR:
        return 'AI Tutor';
      default:
        return 'Nexus AI';
    }
  };

  const selectedGradeForMode =
    activeConversation?.grade || (mode === AppMode.STEM || mode === AppMode.AI_TUTOR ? grades[mode] : undefined);

  return (
    <div className="flex h-[100dvh] w-full bg-slate-100/70 text-slate-900 p-2 sm:p-4 md:p-6 overflow-hidden relative">
      {/* Grade Selector Modal */}
      {isGradeSelectorVisible && (
        <GradeSelector
          onGradeSelect={handleGradeSelect}
          subject={mode === AppMode.STEM ? stemSubMode : 'AI Tutor'}
        />
      )}

      {/* Responsive Sidebar (Desktop & Mobile Drawer) */}
      <Sidebar
        activeMode={mode}
        setMode={handleSetMode}
        activeStemSubMode={stemSubMode}
        setStemSubMode={setStemSubMode}
        conversations={conversations}
        activeConversationId={activeConversationId}
        onSelectConversation={handleSelectConversation}
        onNewConversation={() => setActiveConversationId(null)}
        isMobileOpen={isMobileMenuOpen}
        onMobileClose={() => setIsMobileMenuOpen(false)}
        onReturnToWelcome={handleReturnToWelcome}
      />

      {/* Main Workspace Frame with Calm, Mature Transition */}
      <main className="flex-1 relative flex flex-col min-w-0 bg-white rounded-3xl border border-slate-200/80 shadow-sm ml-0 md:ml-4 overflow-hidden animate-mature-enter">
        {/* Top Navbar */}
        <header className="h-16 sm:h-20 border-b border-slate-100 flex items-center justify-between px-4 sm:px-6 z-20 flex-shrink-0">
          <div className="flex items-center space-x-3 sm:space-x-4 min-w-0">
            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="md:hidden p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors flex-shrink-0"
              aria-label="Open Navigation Menu"
            >
              <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>

            {/* Logo Badge */}
            <div
              onClick={() => handleSetMode(AppMode.DASHBOARD)}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-sky-500 text-white flex items-center justify-center shadow-sm shadow-sky-500/20 cursor-pointer flex-shrink-0 font-bold text-xs sm:text-sm hover:opacity-90 transition-opacity"
            >
              <span>NX</span>
            </div>

            {/* Current Mode Title & Subtext */}
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base md:text-lg font-semibold tracking-tight text-slate-900 truncate max-w-[160px] sm:max-w-xs md:max-w-md">
                {getTitle()}
              </h1>
              <div className="text-[11px] text-slate-500 truncate font-medium">
                {selectedGradeForMode
                  ? `Grade ${selectedGradeForMode} Level`
                  : 'Gemini 3.8 Intelligence'}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 sm:space-x-3 flex-shrink-0">
            {(mode === AppMode.STEM || mode === AppMode.AI_TUTOR) && (
              <button
                onClick={() => setIsGradeSelectorVisible(true)}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-all shadow-sm cursor-pointer"
              >
                Grade {selectedGradeForMode}
              </button>
            )}
          </div>
        </header>

        {/* Viewport Content Area */}
        <div className="flex-1 overflow-hidden relative pb-14 md:pb-0 bg-slate-50/40">
          {mode === AppMode.DASHBOARD && (
            <Dashboard
              onSelectMode={handleSetMode}
            />
          )}
          {mode === AppMode.CHAT && (
            <ChatInterface
              conversation={activeConversation || null}
              onSubmit={handleSubmit}
              isLoading={isLoading}
            />
          )}
          {mode === AppMode.PLANNER && (
            <AiPlanner
              conversation={activeConversation || null}
              onSubmit={handleSubmit}
              isLoading={isLoading}
            />
          )}
          {mode === AppMode.CODE && (
            <CodeBuilder
              conversation={activeConversation || null}
              onSubmit={handleSubmit}
              isLoading={isLoading}
            />
          )}
          {mode === AppMode.TRANSLATE && (
            <Translator
              conversation={activeConversation || null}
              onSubmit={handleSubmit}
              isLoading={isLoading}
            />
          )}
          {mode === AppMode.SEARCH && (
            <SearchProvider
              conversation={activeConversation || null}
              onSubmit={handleSubmit}
              isLoading={isLoading}
            />
          )}
          {mode === AppMode.STEM && (
            <StemSolver
              subMode={stemSubMode}
              grade={selectedGradeForMode || 10}
              conversation={activeConversation || null}
              onSubmit={handleSubmit}
              isLoading={isLoading}
            />
          )}
          {mode === AppMode.AI_TUTOR && (
            <AiTutor
              grade={selectedGradeForMode || 10}
              conversation={activeConversation || null}
              onSubmit={handleSubmit}
              isLoading={isLoading}
            />
          )}
        </div>

        {/* Mobile Bottom Navigation Bar */}
        <nav className="md:hidden absolute bottom-0 left-0 right-0 h-14 bg-white/95 backdrop-blur-md border-t border-slate-200 flex items-center justify-around px-2 z-30">
          <button
            onClick={() => handleSetMode(AppMode.DASHBOARD)}
            className={`flex flex-col items-center justify-center p-1 transition-colors ${
              mode === AppMode.DASHBOARD ? 'text-indigo-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
            </svg>
            <span className="text-[10px]">Overview</span>
          </button>

          <button
            onClick={() => handleSetMode(AppMode.CHAT)}
            className={`flex flex-col items-center justify-center p-1 transition-colors ${
              mode === AppMode.CHAT ? 'text-indigo-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
            <span className="text-[10px]">Chat</span>
          </button>

          <button
            onClick={() => handleSetMode(AppMode.SEARCH)}
            className={`flex flex-col items-center justify-center p-1 transition-colors ${
              mode === AppMode.SEARCH ? 'text-indigo-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
            </svg>
            <span className="text-[10px]">Search</span>
          </button>

          <button
            onClick={() => handleSetMode(AppMode.CODE)}
            className={`flex flex-col items-center justify-center p-1 transition-colors ${
              mode === AppMode.CODE ? 'text-indigo-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
            <span className="text-[10px]">Code</span>
          </button>

          <button
            onClick={() => setIsMobileMenuOpen(true)}
            className="flex flex-col items-center justify-center p-1 text-slate-500 hover:text-slate-800"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
            <span className="text-[10px]">More</span>
          </button>
        </nav>
      </main>

      {/* 3-Second Loading Animation Overlay to Home Screen */}
      {isNavigatingHome && (
        <div className="fixed inset-0 z-[100] bg-slate-50/95 backdrop-blur-md flex flex-col items-center justify-center p-6 select-none animate-in fade-in duration-300">
          {/* Ambient Glow & Concentric Rings */}
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-sky-300/25 rounded-full blur-[140px] pointer-events-none" />
          <div className="absolute w-[360px] h-[360px] sm:w-[480px] sm:h-[480px] rounded-full border border-sky-400/30 animate-aura-pulse pointer-events-none" />
          <div
            className="absolute w-[520px] h-[520px] sm:w-[680px] sm:h-[680px] rounded-full border border-sky-300/20 animate-aura-pulse pointer-events-none"
            style={{ animationDelay: '0.6s' }}
          />

          {/* Center Card */}
          <div className="relative z-10 w-full max-w-sm bg-white border border-sky-200 rounded-3xl p-6 sm:p-8 shadow-xl shadow-sky-500/10 flex flex-col items-center text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-sky-500 text-white flex items-center justify-center font-bold text-lg shadow-md shadow-sky-500/25">
              NX
            </div>

            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                Nexus AI
              </h3>
              <p className="text-xs text-slate-500 font-normal mt-0.5">
                Universal Multimodal Workspace
              </p>
            </div>

            {/* Spinner & Live Status Text */}
            <div className="flex items-center gap-2 text-xs font-semibold text-sky-700 pt-1">
              <svg className="w-4 h-4 animate-spin text-sky-500" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              <span>{homeStatusText}</span>
            </div>

            {/* 3-Second Smooth Progress Bar */}
            <div className="w-full h-2 bg-sky-50 rounded-full overflow-hidden p-0.5 border border-sky-100">
              <div
                className="h-full bg-gradient-to-r from-sky-400 via-sky-500 to-sky-400 rounded-full transition-all duration-100 ease-out"
                style={{ width: `${homeProgress}%` }}
              />
            </div>

            <div className="flex items-center justify-between w-full text-[11px] text-slate-400 font-mono">
              <span>RETURNING TO HOME</span>
              <span>{homeProgress}%</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
