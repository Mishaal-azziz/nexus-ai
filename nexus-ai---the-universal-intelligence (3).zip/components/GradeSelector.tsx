import React from 'react';

interface GradeSelectorProps {
  onGradeSelect: (grade: number) => void;
  subject: string;
}

const GradeSelector: React.FC<GradeSelectorProps> = ({ onGradeSelect, subject }) => {
  const grades = Array.from({ length: 12 }, (_, i) => i + 1);

  return (
    <div className="fixed inset-0 bg-slate-900/30 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 max-w-xl w-full text-center shadow-2xl animate-in zoom-in-95 duration-200">
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2">
          Select Grade Level
        </h2>
        <p className="text-slate-500 text-xs sm:text-sm mb-6">
          Tailor the <span className="font-semibold text-slate-800">{subject}</span> explanations to your target academic level.
        </p>
        <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
          {grades.map((grade) => (
            <button
              key={grade}
              onClick={() => onGradeSelect(grade)}
              className="py-4 rounded-xl bg-slate-50 hover:bg-blue-600 border border-slate-200 hover:border-blue-600 text-slate-700 hover:text-white font-bold text-lg transition-all shadow-sm active:scale-95 cursor-pointer"
            >
              {grade}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default GradeSelector;
