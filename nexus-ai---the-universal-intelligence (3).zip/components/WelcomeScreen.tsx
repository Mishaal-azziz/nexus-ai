import React, { useState, useEffect } from 'react';

interface WelcomeScreenProps {
  onEnter: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onEnter }) => {
  const [isEntering, setIsEntering] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('Initializing workspace...');

  const handleEnterClick = () => {
    if (isEntering) return;
    setIsEntering(true);
    setProgress(0);
    setStatusText('Preparing workspace...');

    const startTime = Date.now();
    const duration = 3000;

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.floor((elapsed / duration) * 100));
      setProgress(pct);

      if (elapsed < 1100) {
        setStatusText('Preparing workspace...');
      } else if (elapsed < 2200) {
        setStatusText('Connecting intelligence suite...');
      } else {
        setStatusText('Opening Dashboard...');
      }

      if (elapsed >= duration) {
        clearInterval(interval);
        setTimeout(() => {
          onEnter();
        }, 100);
      }
    }, 35);
  };

  return (
    <div className="fixed inset-0 w-full h-[100dvh] bg-slate-50 text-slate-900 flex flex-col justify-between p-6 sm:p-10 select-none z-50 overflow-hidden relative">
      {/* Background Soft Ambient Light-Blue Glows */}
      <div
        className={`fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none transition-all duration-1000 ${
          isEntering
            ? 'w-[750px] h-[750px] bg-sky-300/25 blur-[140px] scale-125'
            : 'w-[450px] h-[450px] bg-sky-200/20 blur-[120px]'
        }`}
      />

      {/* Subtle expanding concentric rings during the 3-second transition */}
      {isEntering && (
        <div className="fixed inset-0 flex items-center justify-center pointer-events-none z-10">
          <div className="absolute w-[360px] h-[360px] sm:w-[500px] sm:h-[500px] rounded-full border border-sky-400/30 animate-aura-pulse" />
          <div
            className="absolute w-[520px] h-[520px] sm:w-[720px] sm:h-[720px] rounded-full border border-sky-300/20 animate-aura-pulse"
            style={{ animationDelay: '0.6s' }}
          />
        </div>
      )}

      {/* Top Navigation / Brand */}
      <header className="relative z-20 w-full max-w-5xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-sky-500 text-white flex items-center justify-center font-bold text-sm shadow-sm shadow-sky-500/25">
            NX
          </div>
          <div>
            <div className="text-sm font-semibold tracking-tight text-slate-900">Nexus AI</div>
            <div className="text-xs text-slate-500">Universal Workspace</div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>Gemini Intelligence</span>
        </div>
      </header>

      {/* Center Welcome Container */}
      <main
        className={`relative z-20 w-full max-w-2xl mx-auto my-auto text-center transition-all duration-700 ease-out ${
          isEntering && progress > 85
            ? 'opacity-0 scale-[1.03] translate-y-[-8px]'
            : 'opacity-100 scale-100 translate-y-0'
        }`}
      >
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white border border-sky-200/80 text-xs font-medium text-sky-700 shadow-sm mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-sky-500" />
          <span>Intelligent Multi-Modal Workspace</span>
        </div>

        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-900 mb-5 leading-tight">
          Think, build, and solve <br className="hidden sm:inline" />
          with unified intelligence.
        </h1>

        <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto leading-relaxed mb-8 font-normal">
          An integrated workspace combining conversational reasoning, live web-grounded research, production code synthesis, creative generation, and rigorous STEM analysis.
        </p>

        {/* The Action Button with 3-Second Visual Progress */}
        <div className="flex flex-col items-center justify-center gap-3">
          {!isEntering ? (
            <button
              type="button"
              onClick={handleEnterClick}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-medium text-sm shadow-md shadow-sky-500/25 hover:shadow-lg hover:shadow-sky-500/30 transition-all active:scale-[0.98] cursor-pointer"
            >
              <span>Enter Dashboard</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          ) : (
            <div className="w-full sm:w-80 bg-white border border-sky-200 rounded-2xl p-4 shadow-lg shadow-sky-500/10 flex flex-col items-center space-y-3 animate-in fade-in duration-300">
              {/* Spinner & Live Status Text */}
              <div className="flex items-center gap-2 text-xs font-semibold text-sky-700">
                <svg className="w-4 h-4 animate-spin text-sky-500" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>{statusText}</span>
              </div>

              {/* Smooth 3-Second Progress Bar */}
              <div className="w-full h-2 bg-sky-50 rounded-full overflow-hidden p-0.5 border border-sky-100">
                <div
                  className="h-full bg-gradient-to-r from-sky-400 via-sky-500 to-sky-400 rounded-full transition-all duration-100 ease-out"
                  style={{ width: `${progress}%` }}
                />
              </div>

              <div className="flex items-center justify-between w-full text-[11px] text-slate-400 font-mono">
                <span>OPENING DASHBOARD</span>
                <span>{progress}%</span>
              </div>
            </div>
          )}
        </div>

        {/* Clean Unboxed Metadata Badges */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-y-2 gap-x-3 text-xs text-slate-500 font-medium">
          <span>Conversational Chat</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>Web Grounding</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>Code Architecture</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>AI Planning & Strategy</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>STEM Solver</span>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-20 w-full max-w-5xl mx-auto flex items-center justify-between text-xs text-slate-500 border-t border-slate-200/80 pt-4">
        <div>Nexus AI Workspace</div>
        <div>Fast · Multimodal · Secure</div>
      </footer>
    </div>
  );
};

export default WelcomeScreen;
