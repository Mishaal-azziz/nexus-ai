import React, { useState, useEffect } from 'react';

interface SurpriseIntroProps {
  onComplete: () => void;
}

const SurpriseIntro: React.FC<SurpriseIntroProps> = ({ onComplete }) => {
  const [phase, setPhase] = useState(0);
  const [bootText, setBootText] = useState<string[]>([]);
  const [isMorphing, setIsMorphing] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);

  const systemLogs = [
    'NEURAL_PATHWAYS_MAPPING...',
    'COGNITIVE_CORE_SYNC...',
    'MULTI_DEVICE_ADAPTATION...',
    'NEXUS_INTELLIGENCE_READY',
  ];

  useEffect(() => {
    if (phase === 0) {
      let logIndex = 0;
      const interval = setInterval(() => {
        if (logIndex < systemLogs.length) {
          setBootText((prev) => [...prev, systemLogs[logIndex]]);
          logIndex++;
          setScanProgress((logIndex / systemLogs.length) * 100);
        } else {
          clearInterval(interval);
          setTimeout(() => setPhase(1), 600);
        }
      }, 450);
      return () => clearInterval(interval);
    }
  }, [phase]);

  const handleLogoClick = () => {
    setIsMorphing(true);
    setTimeout(() => {
      setPhase(2);
      setIsMorphing(false);
    }, 800);
  };

  return (
    <div className="fixed inset-0 bg-[#02040a] z-[100] flex items-center justify-center p-4 overflow-hidden">
      {/* Skip Button */}
      <button
        onClick={onComplete}
        className="absolute top-4 right-4 z-50 px-4 py-1.5 rounded-full text-xs font-mono text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
      >
        SKIP INTRO &rarr;
      </button>

      {/* Holographic background */}
      <div className={`absolute top-0 left-0 w-full h-full hologram-grid transition-opacity duration-1000 ${phase > 0 ? 'opacity-20' : 'opacity-10'}`} />

      <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[320px] sm:w-[600px] h-[320px] sm:h-[600px] bg-blue-600/10 rounded-full blur-[100px] sm:blur-[150px] transition-all duration-1000 ${isMorphing ? 'scale-[2.5] opacity-0' : 'opacity-40 animate-pulse'}`} />

      {/* Phase 0: System Boot Loading */}
      {phase === 0 && (
        <div className="relative z-10 flex flex-col items-center w-full max-w-xs text-center">
          <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden mb-6 relative">
            <div
              className="absolute top-0 left-0 h-full bg-cyan-400 transition-all duration-300"
              style={{ width: `${scanProgress}%` }}
            />
          </div>
          <div className="space-y-2 w-full">
            {bootText.map((text, i) => (
              <p key={i} className="text-[10px] sm:text-xs orbitron tracking-[0.25em] text-cyan-400/90 animate-in fade-in duration-200">
                {text}
              </p>
            ))}
          </div>
        </div>
      )}

      {/* Phase 1: Tap to Enter Core */}
      {phase === 1 && (
        <div className={`relative flex flex-col items-center max-w-sm sm:max-w-md w-full transition-all duration-700 ${isMorphing ? 'scale-[3] blur-2xl opacity-0' : 'animate-in fade-in zoom-in duration-700'}`}>
          <div className="mb-4 text-[10px] sm:text-xs orbitron text-cyan-400/80 tracking-[0.5em] uppercase animate-pulse">
            Neural Core Online
          </div>

          <button
            onClick={handleLogoClick}
            className="relative w-48 h-48 sm:w-64 sm:h-64 flex items-center justify-center group cursor-pointer outline-none active:scale-95 transition-transform"
          >
            {/* Spinning Rings */}
            <div className="absolute inset-0 border border-blue-500/20 rounded-[35%] animate-[spin_20s_linear_infinite]" />
            <div className="absolute inset-3 border border-cyan-500/30 rounded-[45%] animate-[spin_15s_linear_infinite_reverse]" />
            <div className="absolute inset-[-10px] border-2 border-dashed border-blue-500/10 rounded-full animate-[spin_40s_linear_infinite]" />

            {/* Glowing Core */}
            <div className="relative w-28 h-28 sm:w-36 sm:h-36 bg-gradient-to-tr from-blue-700 via-indigo-600 to-cyan-400 rounded-full flex items-center justify-center shadow-[0_0_60px_rgba(37,99,235,0.5)] group-hover:shadow-[0_0_90px_rgba(6,182,212,0.7)] transition-all duration-500">
              <span className="relative z-10 text-white orbitron font-black text-4xl sm:text-6xl tracking-tighter group-hover:scale-110 transition-transform">
                NX
              </span>
            </div>
          </button>

          <div className="mt-8 text-center space-y-2">
            <h2 className="text-3xl sm:text-5xl font-black orbitron tracking-[0.2em] text-white">
              NEXUS
            </h2>
            <p className="text-cyan-400/70 text-[10px] sm:text-xs tracking-[0.5em] uppercase orbitron animate-pulse">
              Tap Core to Enter
            </p>
          </div>
        </div>
      )}

      {/* Phase 2: Ready */}
      {phase === 2 && (
        <div className="relative text-center p-6 sm:p-12 bg-blue-950/30 backdrop-blur-2xl rounded-[2.5rem] border border-cyan-500/30 shadow-[0_0_80px_rgba(0,0,0,0.8)] max-w-lg w-full animate-in zoom-in-95 duration-500">
          <div className="inline-block px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 mb-6">
            <span className="text-[10px] orbitron text-cyan-300 font-bold uppercase tracking-[0.3em]">
              Synchronized
            </span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-black orbitron text-white tracking-tight mb-4 leading-none">
            UNIVERSAL <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-cyan-400">
              INTELLIGENCE
            </span>
          </h1>

          <p className="text-gray-300 text-xs sm:text-sm mb-8 font-light max-w-sm mx-auto leading-relaxed">
            Multimodal chat, verified web link research, storytelling, code architecture, and learning.
          </p>

          <button
            onClick={onComplete}
            className="w-full sm:w-auto inline-flex items-center justify-center px-10 py-4 orbitron font-bold text-white transition-all bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 rounded-2xl hover:scale-105 active:scale-95 shadow-xl shadow-blue-500/30 text-xs sm:text-sm tracking-[0.2em]"
          >
            ENTER WORKSPACE &rarr;
          </button>
        </div>
      )}
    </div>
  );
};

export default SurpriseIntro;
