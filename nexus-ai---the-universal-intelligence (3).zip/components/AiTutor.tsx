import React, { useState } from 'react';
import { TutorSubject, Conversation, FileData, QuizQuestion } from '../types';
import { geminiService } from '../geminiService';

interface AiTutorProps {
  grade: number;
  conversation: Conversation | null;
  onSubmit: (prompt: string, attachment?: FileData) => void;
  isLoading: boolean;
}

const AiTutor: React.FC<AiTutorProps> = ({ grade, conversation, onSubmit, isLoading }) => {
  const [prompt, setPrompt] = useState('');
  const [subject, setSubject] = useState<TutorSubject>(TutorSubject.MATH);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [quizLoading, setQuizLoading] = useState(false);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);

  const subjects = Object.values(TutorSubject);

  const latestResponse = conversation?.turns[conversation.turns.length - 1]?.response;
  const output = latestResponse?.type === 'tutor' ? latestResponse.content : '';

  const handleAsk = (customQuestion?: string) => {
    const text = customQuestion || prompt;
    if (!text.trim() || isLoading) return;
    onSubmit(text, { data: '', mimeType: '', name: '', subject } as any);
    setPrompt('');
  };

  const handleStartQuiz = async () => {
    setQuizLoading(true);
    setUserAnswers({});
    setShowResults(false);
    try {
      const topic = prompt.trim() || subject;
      const questions = await geminiService.generateQuiz(subject, grade, topic);
      setQuizQuestions(questions);
    } catch (e) {
      console.error('Quiz generation error:', e);
    } finally {
      setQuizLoading(false);
    }
  };

  const selectAnswer = (questionIndex: number, option: string) => {
    if (showResults) return;
    setUserAnswers((prev) => ({ ...prev, [questionIndex]: option }));
  };

  const calculateScore = () => {
    return quizQuestions.reduce((score, q, idx) => {
      return score + (userAnswers[idx] === q.correctAnswer ? 1 : 0);
    }, 0);
  };

  const sampleQuestions: Record<string, string[]> = {
    [TutorSubject.MATH]: [
      'Explain Pythagorean Theorem with real world triangles',
      'How does compound interest work mathematically?',
      'What is the fundamental theorem of algebra?',
    ],
    [TutorSubject.SCIENCE]: [
      'Why do the seasons change on Earth?',
      'How does the immune system remember viruses?',
      'Explain Newton’s Third Law of Motion with rocket propulsion',
    ],
    [TutorSubject.HISTORY]: [
      'What were the primary economic causes of the Industrial Revolution?',
      'Explain the significance of the Silk Road in cultural exchange',
      'What led to the fall of the Western Roman Empire?',
    ],
    [TutorSubject.LITERATURE]: [
      'What is dramatic irony and how is it used in Shakespeare?',
      'Explain the hero’s journey archetype with modern examples',
      'How do metaphors differ from allegories?',
    ],
    [TutorSubject.GEOGRAPHY]: [
      'How do tectonic plates create mountain ranges and trenches?',
      'Explain ocean conveyor belts and global climate patterns',
      'What causes monsoons in South Asia?',
    ],
  };

  return (
    <div className="h-full flex flex-col p-3 sm:p-6 max-w-7xl mx-auto w-full space-y-4 sm:space-y-6 overflow-hidden">
      {/* Header */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 text-xs font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>PERSONALIZED TUTOR • GRADE {grade}</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-black bg-gradient-to-r from-emerald-600 via-teal-500 to-green-600 bg-clip-text text-transparent tracking-tight">
          Adaptive AI Tutor
        </h2>
        <p className="text-gray-400 text-xs sm:text-sm">
          Interactive concept breakdowns, customized analogies, and diagnostic quizzes.
        </p>
      </div>

      {/* Subject Chips */}
      <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 px-2">
        {subjects.map((sub) => (
          <button
            key={sub}
            onClick={() => {
              setSubject(sub);
              setQuizQuestions([]);
            }}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-full border transition-all ${
              subject === sub
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 border-violet-400 text-white shadow-md'
                : 'bg-white/5 border-white/5 text-gray-400 hover:text-white hover:bg-white/10'
            }`}
          >
            {sub}
          </button>
        ))}
      </div>

      {/* Main Grid */}
      <div className="flex-1 grid lg:grid-cols-2 gap-4 sm:gap-6 min-h-0 overflow-y-auto pr-1">
        {/* Left Column: Input and Tutor Controls */}
        <div className="flex flex-col space-y-3 bg-[#12192e]/90 border border-white/10 rounded-3xl p-4 sm:p-6 backdrop-blur-xl shadow-xl">
          <label className="text-[10px] sm:text-xs text-violet-300 uppercase font-black tracking-widest px-1">
            Question or Topic for {subject}
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={`Ask a question or enter a topic in ${subject}...`}
            className="flex-1 bg-transparent border-none text-gray-100 resize-none focus:ring-0 outline-none text-base sm:text-lg leading-relaxed font-light min-h-[120px]"
            disabled={isLoading || quizLoading}
          />

          {/* Sample Questions */}
          <div className="space-y-1 pt-2 border-t border-white/5">
            <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider">
              Suggested Topics:
            </span>
            <div className="space-y-1">
              {(sampleQuestions[subject] || []).map((sample, i) => (
                <button
                  key={i}
                  onClick={() => handleAsk(sample)}
                  className="w-full text-left text-xs p-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-violet-300 transition-colors truncate"
                >
                  &bull; {sample}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => handleAsk()}
              disabled={isLoading || quizLoading || !prompt.trim()}
              className="py-3 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-indigo-600/20 flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Explaining...</span>
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                  </svg>
                  <span>Explain Concept</span>
                </>
              )}
            </button>

            <button
              onClick={handleStartQuiz}
              disabled={isLoading || quizLoading}
              className="py-3 px-4 rounded-2xl bg-violet-600 hover:bg-violet-500 disabled:opacity-40 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-violet-600/20 flex items-center justify-center space-x-2"
            >
              {quizLoading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Drafting Quiz...</span>
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                  </svg>
                  <span>Generate Practice Quiz</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Explanation or Quiz */}
        <div className="flex flex-col bg-[#0b101e]/90 border border-white/10 rounded-3xl overflow-hidden shadow-xl min-h-[220px]">
          <div className="flex items-center justify-between p-4 border-b border-white/5 bg-black/20">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-violet-400" />
              <label className="text-[10px] text-violet-300 uppercase font-black tracking-widest">
                {quizQuestions.length > 0 ? 'Interactive Practice Quiz' : 'Tutor Dialogue & Breakdown'}
              </label>
            </div>
            {quizQuestions.length > 0 && (
              <button
                onClick={() => setQuizQuestions([])}
                className="text-xs text-gray-400 hover:text-white"
              >
                Back to Explanation
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-4 sm:p-6 scrollbar-thin">
            {quizQuestions.length > 0 ? (
              /* Quiz View */
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-3 border-b border-white/5">
                  <span className="text-xs text-violet-300 font-mono">
                    5 Diagnostic Questions ({subject})
                  </span>
                  {showResults && (
                    <span className="text-xs font-bold text-emerald-400 font-mono">
                      SCORE: {calculateScore()} / {quizQuestions.length}
                    </span>
                  )}
                </div>

                {quizQuestions.map((q, qIdx) => (
                  <div key={qIdx} className="p-4 bg-white/5 rounded-2xl space-y-3">
                    <p className="text-sm font-semibold text-white">
                      {qIdx + 1}. {q.question}
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {q.options.map((opt, oIdx) => {
                        const isSelected = userAnswers[qIdx] === opt;
                        const isCorrect = showResults && opt === q.correctAnswer;
                        const isWrong = showResults && isSelected && opt !== q.correctAnswer;

                        return (
                          <button
                            key={oIdx}
                            onClick={() => selectAnswer(qIdx, opt)}
                            className={`p-2.5 rounded-xl text-xs text-left transition-all border ${
                              isCorrect
                                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 font-bold'
                                : isWrong
                                ? 'bg-red-500/20 border-red-400 text-red-300'
                                : isSelected
                                ? 'bg-violet-600/30 border-violet-400 text-white font-medium'
                                : 'bg-white/5 border-transparent text-gray-300 hover:bg-white/10'
                            }`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}

                <div className="pt-2 flex justify-end">
                  {!showResults ? (
                    <button
                      onClick={() => setShowResults(true)}
                      disabled={Object.keys(userAnswers).length < quizQuestions.length}
                      className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
                    >
                      Check Answers
                    </button>
                  ) : (
                    <button
                      onClick={handleStartQuiz}
                      className="px-6 py-2.5 bg-violet-600 hover:bg-violet-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
                    >
                      Try New Quiz
                    </button>
                  )}
                </div>
              </div>
            ) : isLoading && !output ? (
              <div className="flex flex-col items-center justify-center h-full py-12 space-y-3 opacity-70">
                <div className="w-10 h-10 border-3 border-violet-400 border-t-transparent rounded-full animate-spin" />
                <p className="text-xs font-mono text-violet-300 uppercase tracking-widest">
                  Tutor analyzing concept...
                </p>
              </div>
            ) : output ? (
              <div className="text-sm leading-relaxed text-gray-100 whitespace-pre-wrap font-sans">
                {output}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-gray-500 opacity-40 text-center py-16">
                <svg className="w-12 h-12 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 14l9-5-9-5-9 5 9 5z M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z M12 14v6m-6-3h12" />
                </svg>
                <p className="text-sm uppercase tracking-widest font-mono">Awaiting Student Inquiry</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiTutor;
