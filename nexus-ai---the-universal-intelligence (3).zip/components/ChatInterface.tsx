import React, { useState, useRef, useEffect } from 'react';
import { Conversation, FileData } from '../types';

interface ChatInterfaceProps {
  conversation: Conversation | null;
  onSubmit: (prompt: string, attachment?: FileData) => void;
  isLoading: boolean;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ conversation, onSubmit, isLoading }) => {
  const [input, setInput] = useState('');
  const [attachment, setAttachment] = useState<FileData | null>(null);
  const [isSpeakingId, setIsSpeakingId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [conversation?.turns.length, isLoading]);

  const handleSend = () => {
    if ((!input.trim() && !attachment) || isLoading) return;
    onSubmit(input, attachment || undefined);
    setInput('');
    setAttachment(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachment({
          data: reader.result as string,
          mimeType: file.type,
          name: file.name,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const speakText = (text: string, id: string) => {
    if (!('speechSynthesis' in window)) return;
    if (isSpeakingId === id) {
      window.speechSynthesis.cancel();
      setIsSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 1000));
    utterance.onend = () => setIsSpeakingId(null);
    utterance.onerror = () => setIsSpeakingId(null);
    setIsSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const copyText = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const suggestions = [
    { label: 'Explain Quantum Computing', prompt: 'Explain quantum computing in simple, intuitive terms.' },
    { label: 'Creative Story', prompt: 'Write an engaging narrative exploring the discovery of an ancient library under the ocean.' },
    { label: 'Web Scraper Architecture', prompt: 'Architect a modern resilient web scraper in TypeScript.' },
    { label: 'Solve Calculus Integral', prompt: 'Show step-by-step how to solve the integral of x * e^(2x) dx.' },
  ];

  const messages = conversation?.turns.flatMap((turn) => [
    {
      id: turn.id + '-user',
      role: 'user' as const,
      content: turn.prompt,
      attachment: turn.attachment,
    },
    {
      id: turn.response.id,
      role: 'assistant' as const,
      content: turn.response.content,
      type: turn.response.type,
      metadata: turn.response.metadata,
    },
  ]) || [];

  return (
    <div className="h-full flex flex-col w-full max-w-5xl mx-auto p-4 sm:p-6 relative select-text">
      {/* Messages Scroll Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-6 pb-32 sm:pb-28 pr-1 sm:pr-2 scrollbar-thin">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center min-h-[55vh] text-center px-4 space-y-5 animate-in fade-in duration-500">
            <div className="w-14 h-14 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shadow-sm">
              <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
              </svg>
            </div>

            <div className="space-y-1.5 max-w-md">
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                What can we help you with?
              </h2>
              <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
                Powered by Gemini 3.8 Flash. Ask questions, explore code architectures, solve math problems, or research ideas.
              </p>
            </div>

            {/* Suggestions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full max-w-xl pt-2">
              {suggestions.map((s, i) => (
                <button
                  key={i}
                  onClick={() => onSubmit(s.prompt)}
                  className="p-3.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-left transition-all duration-150 group flex items-center justify-between shadow-sm cursor-pointer"
                >
                  <span className="text-xs sm:text-sm font-medium text-slate-700 group-hover:text-indigo-600 transition-colors">
                    {s.label}
                  </span>
                  <svg className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in duration-200`}
            >
              <div
                className={`max-w-[92%] sm:max-w-[82%] p-4 sm:p-5 rounded-2xl ${
                  msg.role === 'user'
                    ? 'bg-sky-500 text-white shadow-sm shadow-sky-500/15'
                    : msg.type === 'error'
                    ? 'bg-rose-50 border border-rose-200 text-rose-800'
                    : 'bg-white border border-slate-200/90 text-slate-800 shadow-sm'
                }`}
              >
                {/* Header for assistant message */}
                {msg.role === 'assistant' && (
                  <div className="flex items-center justify-between mb-2.5 pb-2 border-b border-slate-100">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-indigo-600" />
                      <span className="text-xs font-semibold text-slate-700">
                        Nexus AI
                      </span>
                    </div>
                    <div className="flex items-center space-x-1 text-slate-400">
                      <button
                        onClick={() => copyText(msg.content)}
                        className="p-1 hover:text-slate-700 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
                        title="Copy text"
                        aria-label="Copy message"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                      </button>
                      <button
                        onClick={() => speakText(msg.content, msg.id)}
                        className={`p-1 rounded-lg transition-colors cursor-pointer ${
                          isSpeakingId === msg.id ? 'text-indigo-600 bg-indigo-50' : 'hover:text-slate-700 hover:bg-slate-50'
                        }`}
                        title="Speak aloud"
                        aria-label="Read message aloud"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                        </svg>
                      </button>
                    </div>
                  </div>
                )}

                {/* Optional attachment thumbnail */}
                {msg.role === 'user' && msg.attachment && (
                  <div className="mb-2 text-xs bg-slate-800 p-2 rounded-xl flex items-center gap-2">
                    <svg className="w-4 h-4 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                    </svg>
                    <span className="truncate">{msg.attachment.name}</span>
                  </div>
                )}

                {/* Message Body */}
                <p className="whitespace-pre-wrap leading-relaxed text-sm sm:text-base font-normal">
                  {msg.content}
                </p>
              </div>
            </div>
          ))
        )}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex justify-start animate-in fade-in duration-200">
            <div className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center space-x-3 shadow-sm">
              <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" />
              <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce [animation-delay:-.2s]" />
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:-.4s]" />
              <span className="text-xs text-slate-500 font-medium">Generating response...</span>
            </div>
          </div>
        )}
      </div>

      {/* Floating Bottom Input Bar */}
      <div className="absolute bottom-4 sm:bottom-6 left-3 right-3 sm:left-6 sm:right-6 max-w-4xl mx-auto">
        <div className="flex items-center bg-white border border-slate-200/90 rounded-2xl shadow-lg p-1.5 sm:p-2 pl-3 sm:pl-4 pr-2">
          {/* Attachment Button */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            className="hidden"
            accept="image/*,text/*,application/pdf"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className={`p-2 rounded-xl transition-colors flex-shrink-0 cursor-pointer ${
              attachment ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-50'
            }`}
            title="Attach document or image"
            aria-label="Attach file"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
            </svg>
          </button>

          {attachment && (
            <div className="flex items-center gap-1.5 bg-indigo-50 text-indigo-700 text-xs px-2.5 py-1 rounded-lg border border-indigo-200 max-w-[140px] truncate ml-1">
              <span className="truncate">{attachment.name}</span>
              <button onClick={() => setAttachment(null)} className="text-indigo-400 hover:text-indigo-700 cursor-pointer">
                &times;
              </button>
            </div>
          )}

          {/* Input Field */}
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ask a question, brainstorm ideas, or analyze..."
            className="flex-1 bg-transparent border-none py-2.5 px-3 text-slate-800 placeholder-slate-400 focus:ring-0 outline-none text-sm sm:text-base min-w-0"
            disabled={isLoading}
          />

          {/* Send Button */}
          <button
            onClick={handleSend}
            disabled={isLoading || (!input.trim() && !attachment)}
            className="p-2.5 sm:p-3 bg-sky-500 hover:bg-sky-600 disabled:opacity-30 text-white rounded-xl transition-all shadow-sm shadow-sky-500/20 flex-shrink-0 cursor-pointer disabled:cursor-not-allowed"
            aria-label="Send message"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
