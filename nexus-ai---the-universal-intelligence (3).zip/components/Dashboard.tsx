import React from 'react';
import { AppMode } from '../types';

interface DashboardProps {
  onSelectMode: (mode: AppMode) => void;
}

const Dashboard: React.FC<DashboardProps> = ({
  onSelectMode,
}) => {
  const tools = [
    {
      mode: AppMode.CHAT,
      title: 'Chatbot',
      desc: 'Engage in multi-turn conversational reasoning, brainstorming, and creative writing.',
      category: 'Chat',
      iconBg: 'bg-indigo-50 text-indigo-600',
      icon: 'M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z',
    },
    {
      mode: AppMode.SEARCH,
      title: 'Advanced Search',
      desc: 'Ground queries with verified real-time web knowledge, direct citations, and live sources.',
      category: 'Web Research',
      iconBg: 'bg-emerald-50 text-emerald-600',
      icon: 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7',
    },
    {
      mode: AppMode.CODE,
      title: 'Code Builder',
      desc: 'Draft clean production architectures, algorithms, backend routes, and refactoring.',
      category: 'Engineering',
      iconBg: 'bg-slate-100 text-slate-800',
      icon: 'M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4',
    },
    {
      mode: AppMode.PLANNER,
      title: 'AI Planner',
      desc: 'Formulate structured daily schedules, project sprints, travel itineraries, and interactive checklists.',
      category: 'Productivity',
      iconBg: 'bg-indigo-50 text-indigo-600',
      icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4',
    },
    {
      mode: AppMode.STEM,
      title: 'STEM Solver',
      desc: 'Solve rigorous calculus, physics, and chemistry equations with step-by-step proofs.',
      category: 'Analysis',
      iconBg: 'bg-amber-50 text-amber-600',
      icon: 'M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z',
    },
    {
      mode: AppMode.TRANSLATE,
      title: 'Translator',
      desc: 'Accurately translate text, structured documents, and conversational speech across languages.',
      category: 'Language',
      iconBg: 'bg-teal-50 text-teal-600',
      icon: 'M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5c1.382 3.307 3.454 6.333 5.67 9',
    },
    {
      mode: AppMode.AI_TUTOR,
      title: 'AI Tutor',
      desc: 'Personalized interactive tutoring, structured curriculum explanations, and diagnostic quizzes.',
      category: 'Education',
      iconBg: 'bg-emerald-50 text-emerald-600',
      icon: 'M12 14l9-5-9-5-9 5 9 5z M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z M12 14v6m-6-3h12',
    },
  ];

  return (
    <div className="h-full flex flex-col p-6 sm:p-8 lg:p-10 overflow-y-auto bg-slate-50/50">
      {/* Header Overview */}
      <div className="mb-8 max-w-5xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              Workspace Overview
            </h1>
            <p className="text-slate-600 text-sm mt-1 max-w-2xl font-normal leading-relaxed">
              Select an intelligent modality to research topics, write and execute code, synthesize graphics, or solve equations.
            </p>
          </div>
        </div>
      </div>

      {/* Grid of Tools */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5 max-w-7xl pb-16">
        {tools.map((tool) => (
          <button
            key={tool.mode}
            onClick={() => onSelectMode(tool.mode)}
            className="group relative text-left bg-white border border-slate-200/80 hover:border-slate-300 rounded-2xl p-5 sm:p-6 hover:shadow-md transition-all duration-200 flex flex-col justify-between shadow-sm cursor-pointer"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div
                  className={`w-11 h-11 rounded-xl ${tool.iconBg} flex items-center justify-center transition-transform group-hover:scale-105`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={tool.icon} />
                  </svg>
                </div>
                <span className="text-xs text-slate-500 font-medium">
                  {tool.category}
                </span>
              </div>

              <h3 className="text-base font-semibold text-slate-900 mb-1.5 group-hover:text-indigo-600 transition-colors">
                {tool.title}
              </h3>
              <p className="text-slate-600 text-xs sm:text-sm leading-relaxed font-normal">
                {tool.desc}
              </p>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-medium text-slate-500 group-hover:text-indigo-600 transition-colors">
              <span>Open tool</span>
              <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
